-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 24, 2022 at 12:56 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clothishop`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

DROP TABLE IF EXISTS `tbl_admin`;
CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `full_name`, `username`, `password`) VALUES
(6, 'Dev admin', 'admin123', 'e6e061838856bf47e1de730719fb2609'),
(7, 'iadmin', 'iamadmin', 'e6e061838856bf47e1de730719fb2609');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_buy`
--

DROP TABLE IF EXISTS `tbl_buy`;
CREATE TABLE IF NOT EXISTS `tbl_buy` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product` varchar(150) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `Total` int(20) UNSIGNED NOT NULL,
  `color` varchar(50) NOT NULL,
  `size` varchar(100) NOT NULL,
  `order_date` datetime NOT NULL,
  `status` varchar(50) NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `customer_contact` varchar(20) NOT NULL,
  `customer_email` varchar(150) NOT NULL,
  `country` varchar(50) NOT NULL,
  `state` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `pincode` int(10) UNSIGNED NOT NULL,
  `landmark` varchar(150) NOT NULL,
  `area` varchar(250) NOT NULL,
  `house_no` int(5) UNSIGNED NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `a_code` varchar(10) NOT NULL,
  `delivery` decimal(10,0) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

DROP TABLE IF EXISTS `tbl_category`;
CREATE TABLE IF NOT EXISTS `tbl_category` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `title`, `image_name`, `featured`, `active`) VALUES
(18, 'Men Wear', 'Food_category_884.jpg', 'YES', 'YES'),
(19, 'Women Wear', 'Food_category_757.jpg', 'YES', 'YES'),
(20, 'Kids Wear', 'Food_category_619.jpg', 'YES', 'YES'),
(21, 'Men Trendy', 'Porduct_category_809.jpg', 'YES', 'YES'),
(22, 'Indian Culture', 'Porduct_category_52.jpg', 'YES', 'YES'),
(23, 'Wedding/Festival Special', 'Porduct_category_464.jpg', 'YES', 'YES'),
(24, 'new', 'Porduct_category_161.jpg', 'YES', 'YES');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact_us`
--

DROP TABLE IF EXISTS `tbl_contact_us`;
CREATE TABLE IF NOT EXISTS `tbl_contact_us` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(150) NOT NULL,
  `message` varchar(450) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_detail`
--

DROP TABLE IF EXISTS `tbl_detail`;
CREATE TABLE IF NOT EXISTS `tbl_detail` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `image_name1` varchar(255) NOT NULL,
  `image_name2` varchar(255) NOT NULL,
  `image_name3` varchar(255) NOT NULL,
  `image_name4` varchar(255) NOT NULL,
  `ftype` varchar(10) NOT NULL,
  `color` varchar(50) NOT NULL,
  `size` varchar(50) NOT NULL,
  `category_name` varchar(150) NOT NULL,
  `shipping_area` varchar(100) NOT NULL,
  `description` varchar(450) NOT NULL,
  `active` varchar(5) NOT NULL,
  `featured` varchar(5) NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `delivery` decimal(10,0) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_detail`
--

INSERT INTO `tbl_detail` (`id`, `title`, `price`, `image_name1`, `image_name2`, `image_name3`, `image_name4`, `ftype`, `color`, `size`, `category_name`, `shipping_area`, `description`, `active`, `featured`, `category_id`, `product_code`, `delivery`) VALUES
(26, 'Checks shirt ', '899', 'Product_name_552.jpg', 'Product_name_517.jpg', 'Product_name_336.jpg', 'Product_name_757.jpg', 'Cotton', 'Black', 'XL', 'Men', 'All Over the India', 'Red checks shirt for men.Best fabric and fitting.', 'YES', 'YES', 18, 'P054271', '50'),
(27, 'Trendy Dress', '1588', 'Product_name_403.jpg', 'Product_name_541.png', 'Product_name_146.jpg', 'Product_name_997.jpg', 'Silk', 'Green', 'XL', 'Women', 'All Over the India', 'Beautiful and trendy dress for women.Best fabric and design.', 'YES', 'YES', 19, 'P06517', '90'),
(28, 'Designer Suit', '2500', 'Product_name_687.jpg', 'Product_name_540.jpg', 'Product_name_941.jpg', 'Product_name_31.jpg', 'Cotton', 'Black', 'XL', 'Men', 'Mumbai', 'Designer suit for men with good fabric and design.', 'YES', 'YES', 18, 'P071418', '150'),
(30, 'Perfect Shirt', '499', 'Product_name_243.png', 'Product_name_498.jpg', 'Product_name_573.jpg', 'Product_name_463.png', 'Cotton', 'Green', 'L', 'Men', 'Maharahstra,Goa', 'Best fabric checks shirt for men with perfect fitting.', 'YES', 'YES', 18, 'P089116', '40'),
(31, 'Dress for Bride', '6500', 'Product_name_258.jpg', 'Product_name_387.jpg', 'Product_name_302.jpg', 'Product_name_893.jpg', 'Silk', 'Red', 'XXL', 'WOMEN', 'All Over the India', 'Beautiful and Designer Suit for Bride.All over the work design.', 'YES', 'YES', 23, 'P036272', '200'),
(32, 'Long Skirt Dress', '1599', 'Product_name_96.jpeg', 'Product_name_406.jpg', 'Product_name_868.jpeg', 'Product_name_241.jpg', 'Silk', 'White', 'M', 'KIDS', 'Mumbai,Delhi', 'Beautiful long skirt dress for girl with light colours.', 'YES', 'YES', 20, 'P079095', '150'),
(33, 'T-shirt and Jeans', '2500', 'Product_name_536.jpg', 'Product_name_400.jpg', 'Product_name_969.jpg', 'Product_name_910.jpg', 'Cotton', 'Whiite,blue', 'XL', 'MEN', 'All Over the India', 'Trendy T-shirt and jeans for men.Best fabric and colours.', 'YES', 'YES', 21, 'P076857', '300'),
(34, 'Trendy Dress for Women', '2499', 'Product_name_922.jpg', 'Product_name_696.jpg', 'Product_name_994.jpg', 'Product_name_476.jpg', 'Cotton', 'Withe,black', 'XL', 'WOMEN', 'All Over the India', 'Best Designed and coloured trendy dress for women.', 'YES', 'YES', 19, 'P055078', '200'),
(35, 'Kids Dress', '1200', 'Product_name_760.jpg', 'Product_name_817.jpg', 'Product_name_104.jpg', 'Product_name_770.jpg', 'cotton', 'Black,Yellow', 'M', 'Kids', 'india', 'Beatiful Dress for Kids.BEst fabric and colurs.', 'YES', 'YES', 20, 'P072312', '400'),
(36, 'kcjkhjx', '4884', 'Product_name_275.jpg', '', '', '', 'doo', 'fkjkj', 'xl', 'dmdd', 'dmd', 'fjkjfjf', 'YES', 'YES', 18, 'P020353', '995');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gallery`
--

DROP TABLE IF EXISTS `tbl_gallery`;
CREATE TABLE IF NOT EXISTS `tbl_gallery` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `image_name` varchar(255) NOT NULL,
  `title` varchar(150) NOT NULL,
  `active` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_gallery`
--

INSERT INTO `tbl_gallery` (`id`, `image_name`, `title`, `active`) VALUES
(7, 'Gallery_image_28.webp', 'ddd', 'YES'),
(10, 'Gallery_image_456.jpg', '1', 'NO'),
(11, 'Gallery_image_616.jpg', '2', 'NO'),
(12, 'Gallery_image_469.jpg', '3', 'NO'),
(13, 'Gallery_image_442.jpg', '4', 'NO'),
(14, 'Gallery_image_733.jpg', '5', 'NO');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_opt`
--

DROP TABLE IF EXISTS `tbl_opt`;
CREATE TABLE IF NOT EXISTS `tbl_opt` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(250) NOT NULL,
  `otp` int(100) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `a_code` varchar(10) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `email` varchar(150) NOT NULL,
  `username` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `c_password` varchar(255) NOT NULL,
  `otp` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `first_name`, `last_name`, `a_code`, `contact`, `email`, `username`, `password`, `c_password`, `otp`) VALUES
(1, 'User', 'Name', '9', '99999999999', 'User@gmail.com', 'user123', 'user@123', '', '1');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
