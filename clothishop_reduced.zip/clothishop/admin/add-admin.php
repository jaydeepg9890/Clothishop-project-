<?php include('part/menu.php'); ?>
<div class="main-content">
    <div class="wrapper">
        <h1>Add admin</h2>
          
        <br><br>
        <?php
                if(isset($_SESSION['add'])) //cheking whether the session is set or not
                {
                  echo $_SESSION['add']; //Displaying the message if SET
                  unset($_SESSION['add']); //Removing the message
                }
             
        ?>


        <form action="" method="POST">

           <table class="tbl-30">
                 <tr>
                     <td>Full Name: </td>
                      <td><input type="text" name="Full_name" placeholder="Enter your name"></td>
                 </tr>

                 <tr>
                     <td>Username: </td>
                      <td><input type="text" name="Username" placeholder="Enter your username" required></td>
                 </tr>

                 <tr>
                     <td>Password: </td>
                      <td><input type="password" name="Password" placeholder="Enter your password"></td>
                 </tr>

                 <tr>
                     <td colspan="2">
                         <input type="submit" name="submit" value="Add Admin" class="btn-secondary">
                      <td>
                </tr>     
                      
           </table>
       </from>

</div>    
</div>
<?php
     //process the value from form and save it in database.

     //check wether the submit button is clicked or not.

     if(isset($_POST['submit']))
     {
         // button clicked.
         //echo "button clicked";
     
         //1.Get the data from form
         $full_name = $_POST['Full_name'];
         $username = $_POST['Username'];
         $password = md5($_POST['Password']); //password encryption with md5   

         //2.sql query to save the sata into database.

         $sql = "INSERT INTO tbl_admin SET
             full_name='$full_name',
             username='$username',
             password='$password'
         ";
      
        //3.Executing the query and saving data into database 
        $res = mysqli_query($conn, $sql) or die(mysql_error());
  
        //4.check wether the query is executed data is inserted or not and display appropriate message.
        if($res==TRUE)
        {
           //data inserted
           //echo "Data Inserted";
           //create a session variable to display the message
           $_SESSION['add'] = "<div class='success'>Admin added successfully.</div>";
           //redirect page to manage admin
           header("location:".SITEURL.'admin/manage-admin.php');
           ob_enf_fluch();
        } 
        else
        {
           //Data is not inserted
           //create a session variable to display the message
           $_SESSION['add'] = "<div class='error'>OOPS Failed to add admin.</div>";
           //redirect page to add admin page
           header("location:".SITEURL.'admin/add-admin.php');
           ob_enf_fluch();
        } 
  
     }
     
?>
<?php include('part/footer.php'); ?>