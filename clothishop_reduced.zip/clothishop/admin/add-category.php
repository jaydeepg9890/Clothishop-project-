<?php include('part/menu.php'); ?>
<div class="main-content">
    <div class="wrapper">
        <h1>Add Category</h2>
        
        <br><br>  
        <?php
                if(isset($_SESSION['add'])) //cheking whether the session is set or not
                {
                  echo $_SESSION['add']; //Displaying the message if SET
                  unset($_SESSION['add']); //Removing the message
                }

                if(isset($_SESSION['upload'])) //cheking whether the session is set or not
                {
                  echo $_SESSION['upload']; //Displaying the message if SET
                  unset($_SESSION['upload']); //Removing the message
                }

        ?>
        <br><br>

        <!-- Add category form starts-->
        <form action="" Method="POST" enctype="multipart/form-data">

            <table class="tbl-30">

               <tr>
                   <td>Title:</td>
                   <td>
                       <input type="text" name="title" placeholder="Enter Category Title">
                   </td>
               </tr>

               <tr>
                   <td>Select Image:</td>
                   <td>
                       <input type="file" name="image">
                   </td>
               </tr>

               <tr>
                   <td>Featured:</td>
                   <td>
                       <input type="radio" name="featured" value="YES">YES
                       <input type="radio" name="featured" value="NO">NO
                   </td>
               </tr>

               <tr>
                   <td>Active:</td>
                   <td>
                       <input type="radio" name="active" value="YES">YES
                       <input type="radio" name="active" value="NO">NO
                   </td>
               </tr>

               <tr>
                     <td colspan="2">
                         <input type="submit" name="submit" value="Add Category" class="btn-secondary">
                      <td>
                </tr> 

            </table>
         </form>           

        <!-- Add Category form ends-->

        <?php
        
            //Check Whether the button is clicked or not
            if(isset($_POST['submit']))
            {
                //echo "clicked";


                //1.Gret the value from form
                $title = $_POST['title'];

                //For Radio input , we need to check whether the button is clicked or not
                if(isset($_POST['featured']))
                {
                    //Get the value from form 
                    $featured = $_POST['featured'];
                    
                }
                else
                {
                    //Set the default value 
                    $featured = "NO";
                    
                }

                if(isset($_POST['active']))
                {
                    //Get the value from form 
                    $active = $_POST['active'];
                    
                }
                else
                {
                    //Set the default value 
                    $active = "NO";
                }   

                //Check Wheher the image is selected or not adnd set the value for image name accordingly
                //print_r($_FILES['image']); //to check file is selected or not
                 
                //die(); //Break the code here
                 
                if(isset($_FILES['image']['name']))
                {
                    //Upload the image
                    //To upload the image we need image name,source path and destination path
                    $image_name = $_FILES['image']['name']; 
                     
                    //upload the image if image is selected
                    if($image_name !="")
                    {


                        //Auto rename our page 
                       //Get the extension of our image (jpg,png,gif,etc) for example: "product.jpg"
                       $ext = end(explode('.', $image_name));

                       //Rename the image name
                       $image_name = "Porduct_category_".rand(000, 999).'.'.$ext; // for example "Food_category_987.pjg"
                    

                       //Get the source path and destination path 
                       $source_path = $_FILES['image']['tmp_name'];
 
                       $destination_path = "../images/category/".$image_name;
   
                       //final stage to Upload the image
                       $upload = move_uploaded_file($source_path, $destination_path);

                       //Check whether the image is uploaded is not
                       //and if the image is not uplaoded thene we will stop the process and redirect with eroor message
                       if($upload==false)
                       {
                          //Set message
                          $_SESSION['upload'] = "<div class='error'>Failed to upload the image.</div>";
                          //Redirectto category page 
                          header("location:".SITEURL.'admin/add-category.php');
                          ob_enf_fluch();
                          //stop the process
                           die();
                       }

                }   
                }
                else
                {
                    //Do not upload the image
                    $image_name="";
                }

                //2.Create SQL query to insert category into database
                $sql = "INSERT INTO tbl_category SET
                   title='$title',
                   image_name='$image_name',
                   featured='$featured',
                   active='$active'
                   ";
                
                //3.Execute the query and in database
                $res = mysqli_query($conn, $sql);


                //4.Check whther the query is executed or not
                if($res==TRUE)
                {
                    //Query executed successfully
                    $_SESSION['add'] = "<div class='success'>Category added successfully.</div>";
                    //Redirect page to manage admin
                    header("location:".SITEURL.'admin/manage-category.php');
                    ob_enf_fluch();
                } 
                else
                {
                    //Failed to add category 
                   $_SESSION['add'] = "<div class='error'>OOPS Failed to add category.</div>";
                   //Redirect page to add manage category page
                   header("location:".SITEURL.'admin/add-category.php');
                   ob_enf_fluch();
                } 

           
            }


        ?>

    </div>     
     
</div>   
<?php include('part/footer.php'); ?>