<?php include('part/menu.php'); ?>
      <div class="main-content">
        <div class="wrapper">
           <h1>Add Products</h2>
           <!-- Button to add category -->
           <br><br>
           
           <?php
               
               if(isset($_SESSION['upload'])) //cheking whether the session is set or not
               {
                 echo $_SESSION['upload']; //Displaying the message if set
                 unset($_SESSION['upload']); //Removing the message
               }              

           ?>
           
           <form action="" Method="POST" enctype="multipart/form-data">

              <table class="tbl-30">

                 <tr>
                    <td>Title:</td>
                    <td>
                       <input type="text" name="title" placeholder="Title for Product">
                    </td>
                </tr>

                <tr>
                    <td>Product Code:</td>
                    <td>
                     
                     <?php  $product_code = "P0".rand(00011, 99999);
                        echo $product_code; 
                     ?>
                    </td>

                </tr>
                
                <tr>
                    <td>Description:</td>
                    <td>
                       <textarea name="description" cols="30" rows="5" placeholder="Description of the Product"></textarea>
                    </td>
                </tr>

                <tr>
                    <td>price:</td>
                    <td>
                       Rs<input type="number" name="price">
                    </td>
                </tr>

                <tr>
                    <td> Delivery Charges:</td>
                    <td>
                       Rs<input type="number" name="delivery_charges">
                    </td>
                </tr>

                <tr>
                    <td>Select Image 1:</td>
                    <td>
                       <input type="file" name="image1">
                    </td>
                </tr>

                <tr>
                    <td>Select Image 2:</td>
                    <td>
                       <input type="file" name="image2">
                    </td>
                </tr>

                <tr>
                    <td>Select Image 3:</td>
                    <td>
                       <input type="file" name="image3">
                    </td>
                </tr>

                <tr>
                    <td>Select Image 4:</td>
                    <td>
                       <input type="file" name="image4">
                    </td>
                </tr>

                <tr>
                    <td>Category:</td>
                    <td>
                       <select name="category">
                           
                            <?php
                                //Create php code to display categories from database
                                //1.Create SQL query to get all active categories from database
                                $sql = "SELECT *FROM tbl_category WHERE active='YES'";

                                $res = mysqli_query($conn, $sql);

                                //Count rows to whether we have categories
                                $count = mysqli_num_rows($res);
                                
                                //If count is greater then zero,we have ceategroies else we dont have caegories
                                if($count>0)
                                {
                                    //we have categeories
                                    while($row=mysqli_fetch_assoc($res))
                                    {
                                        //Get the details of categories 
                                        $id = $row['id'];
                                        $title = $row['title'];
                                        
                                        ?>
                                        <option value="<?php echo $id; ?>"><?php echo $title; ?></option>
                                        <?php
                                    }
                                } 
                                else
                                {
                                    //We dont have category
                                    ?>
                                    <option value="0">No category found.</option>
                                    <?php
                                }

                                //2.Display on dropdown
                            ?>
                       </select> 
                    </td>
                </tr>

                <tr>
                    <td>Colour:</td>
                    <td>
                       <input type="text" name="color" placeholder="Colour">
                    </td>
                </tr>

                <tr>
                    <td>Size:</td>
                    <td>
                       <input type="text" name="size" placeholder="Eg. M,L,XL,XXL">
                    </td>
                </tr>

                <tr>
                    <td>Fabric Type:</td>
                    <td>
                       <input type="text" name="fab_type" placeholder="Eg. Cotton,silk... etc">
                    </td>
                </tr>

                <tr>
                    <td>Category Name:</td>
                    <td>
                       <input type="text" name="category_name" placeholder="Category Name">
                    </td>
                </tr>

                <tr>
                    <td>Shipping Area:</td>
                    <td>
                       <input type="text" name="shipping_area" placeholder="Shipping Area">
                    </td>
                </tr>

                <tr>
                    <td>Featured:</td>
                    <td>
                       <input type="radio" name="featured" value="YES">YES
                       <input type="radio" name="featured" value="NO">NO
                   </td>
                </tr>

                <tr>
                    <td>Active:</td>
                    <td>
                       <input type="radio" name="active" value="YES">YES
                       <input type="radio" name="active" value="NO">NO
                   </td>
                </tr>
                 
                <tr>
                   <td colspan="2">
                       <input type="submit" name="submit" value="Add Product" class="btn-secondary">
                   </td>
                </tr>
                
              </table>
        
            </form>


            <?php
                //1.Get the data from form 
                //Check whether the button is cliecked or not
                if(isset($_POST['submit']))
                {
                    
                    //Add the product in database
                    $title = $_POST['title'];
                    $description = $_POST['description'];
                    $price = $_POST['price'];
                    $size = $_POST['size'];
                    $color = $_POST['color'];
                    $type = $_POST['fab_type'];
                    $delivery = $_POST['delivery_charges'];
                    $category_name = $_POST['category_name'];
                    $shipping_area = $_POST['shipping_area'];
                    $category = $_POST['category'];
                    
                    //Check whether buutton for feateured and active iare checked or not
                    if(isset($_POST['featured']))
                    {
                        //Get the value from form 
                        $featured = $_POST['featured'];
                        
                    }
                    else
                    {
                        //Set the default value 
                        $featured = "NO";
                        
                    }
    
                    if(isset($_POST['active']))
                    {
                        //Get the value from form 
                        $active = $_POST['active'];
                        
                    }
                    else
                    {
                        //Set the default value 
                        $active = "NO";
                    }                     

            //2. first Uplaoad the images if selected 
                    //Check Wheher the image is selected or not adnd set the value for image name accordingly
                    //print_r($_FILES['image']); //to check file is selected or not
                 
                    //die(); //Break the code here
                    if(isset($_FILES['image1']['name']))
                    {
                      //Upload the image
                      //To upload the image we need image name,source path and destination path
                       $image_name1 = $_FILES['image1']['name']; 
                      
                       //upload the image if image is selected
                       if($image_name1 != "")
                       {
   

                         //Auto rename our page 
                         //Get the extension of our image (jpg,png,gif,etc) for example: "product.jpg"
                         $ext = end(explode('.', $image_name1));

                         //Rename the image name
                         $image_name1 = "Product_name_".rand(000, 999).'.'.$ext; // for example "Food_category_987.pjg"
                    

                         //Get the source path and destination path 
                         $source_path = $_FILES['image1']['tmp_name'];
   
                         $destination_path = "../images/products/".$image_name1;
   
                         //final stage to Upload the image
                         $upload = move_uploaded_file($source_path, $destination_path);

                         //Check whether the image is uploaded is not
                         //and if the image is not uplaoded thene we will stop the process and redirect with eroor message
                          if($upload==false)
                          {
                            //Set message
                            $_SESSION['upload'] = "<div class='error'>Failed to upload the image.</div>";
                            //Redirectto category page 
                            header("location:".SITEURL.'admin/add-product.php');
                            ob_enf_fluch();
                            //stop the process
                             die();
                          }

                       }   
                    }
                    else
                    {
                      //Do not upload the image
                      $image_name1="";
                    }

          //second Image upload

                if(isset($_FILES['image2']['name']))
                {
                     //Upload the image
                     //To upload the image we need image name,source path and destination path
                     $image_name2 = $_FILES['image2']['name']; 
            
                      //upload the image if image is selected
                      if($image_name2 != "")
                      {


                      //Auto rename our page 
                      //Get the extension of our image (jpg,png,gif,etc) for example: "product.jpg"
                      $ext = end(explode('.', $image_name2));

                      //Rename the image name
                      $image_name2 = "Product_name_".rand(000, 999).'.'.$ext; // for example "Food_category_987.pjg"
          

                      //Get the source path and destination path 
                      $source_path = $_FILES['image2']['tmp_name'];

                      $destination_path = "../images/products/".$image_name2;

                      //final stage to Upload the image
                      $upload = move_uploaded_file($source_path, $destination_path);

                      //Check whether the image is uploaded is not
                      //and if the image is not uplaoded thene we will stop the process and redirect with eroor message
                      if($upload==false)
                      {
                       //Set message
                       $_SESSION['upload'] = "<div class='error'>Failed to upload the image.</div>";
                       //Redirectto category page 
                       header("location:".SITEURL.'admin/add-product.php');
                       ob_enf_fluch();
                       //stop the process
                       die();
                     }
 
               }   
            }
            else
            {
              //Do not upload the image
              $image_name2="";
            }

            
          //third Image upload

          if(isset($_FILES['image3']['name']))
          {
               //Upload the image
               //To upload the image we need image name,source path and destination path
               $image_name3 = $_FILES['image3']['name']; 
      
                //upload the image if image is selected
                if($image_name3 != "")
                {


                //Auto rename our page 
                //Get the extension of our image (jpg,png,gif,etc) for example: "product.jpg"
                $ext = end(explode('.', $image_name3));

                //Rename the image name
                $image_name3 = "Product_name_".rand(000, 999).'.'.$ext; // for example "Food_category_987.pjg"
    

                //Get the source path and destination path 
                $source_path = $_FILES['image3']['tmp_name'];

                $destination_path = "../images/products/".$image_name3;

                //final stage to Upload the image
                $upload = move_uploaded_file($source_path, $destination_path);

                //Check whether the image is uploaded is not
                //and if the image is not uplaoded thene we will stop the process and redirect with eroor message
                if($upload==false)
                {
                 //Set message
                 $_SESSION['upload'] = "<div class='error'>Failed to upload the image.</div>";
                 //Redirectto category page 
                 header("location:".SITEURL.'admin/add-product.php');
                 ob_enf_fluch();
                 //stop the process
                 die();
               }

         }   
      }
      else
      {
        //Do not upload the image
        $image_name3="";
      }

                //fourth Image upload

                if(isset($_FILES['image4']['name']))
                {
                     //Upload the image
                     //To upload the image we need image name,source path and destination path
                     $image_name4 = $_FILES['image4']['name']; 
            
                      //upload the image if image is selected
                      if($image_name4 != "")
                      {
      
      
                      //Auto rename our page 
                      //Get the extension of our image (jpg,png,gif,etc) for example: "product.jpg"
                      $ext = end(explode('.', $image_name4));
      
                      //Rename the image name
                      $image_name4 = "Product_name_".rand(000, 999).'.'.$ext; // for example "Food_category_987.pjg"
          
      
                      //Get the source path and destination path 
                      $source_path = $_FILES['image4']['tmp_name'];
      
                      $destination_path = "../images/products/".$image_name4;
      
                      //final stage to Upload the image
                      $upload = move_uploaded_file($source_path, $destination_path);
      
                      //Check whether the image is uploaded is not
                      //and if the image is not uplaoded thene we will stop the process and redirect with eroor message
                      if($upload==false)
                      {
                       //Set message
                       $_SESSION['upload'] = "<div class='error'>Failed to upload the image.</div>";
                       //Redirectto category page 
                       header("location:".SITEURL.'admin/add-product.php');
                       ob_enf_fluch();
                       //stop the process
                       die();
                     }
      
               }   
            }
            else
            {
              //Do not upload the image
              $image_name4 ="";
            }

                      //3.Insert data into database

                      //Create SQL query to insert category into database
                      //For nu,merical value we do not need to pass value inside ''quotes but for string value it is compulsary to enclosed the value inside ''quotes 
                      $sql2 = "INSERT INTO tbl_detail SET
                         title = '$title',
                         product_code = '$product_code',
                         description = '$description',
                         price = $price,
                         delivery = $delivery,
                         size = '$size',
                         color = '$color',
                         ftype = '$type',
                         shipping_area = '$shipping_area',
                         image_name1 = '$image_name1',
                         image_name2 = '$image_name2',
                         image_name3 = '$image_name3',
                         image_name4 = '$image_name4',
                         category_name = '$category_name',
                         category_id = $category,
                         featured = '$featured',
                         active = '$active'
                         ";
             
                      //Execute the query and in database
                      $res2 = mysqli_query($conn, $sql2);


                      //4.Check whther the query is executed or not
                      if($res2==TRUE)
                      {
                      //Query executed successfully
                      $_SESSION['add'] = "<div class='success'>Product added successfully.</div>";
                      //Redirect page to manage admin
                      header("location:".SITEURL.'admin/manage-product.php');
                      ob_enf_fluch();
                      } 
                      else
                      {
                        //Failed to add category 
                        $_SESSION['add'] = "<div class='error'>OOPS Failed to add Product.</div>";
                     
                        //4.Redirect page to add manage category page
                        header("location:".SITEURL.'admin/manage-product.php');
                        ob_enf_fluch();
                      }
   
                }

            ?>
        </div>
      </div>  

<?php include('part/footer.php'); ?>