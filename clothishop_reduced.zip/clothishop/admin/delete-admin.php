<?php
     //include constrants.php file here
     include('../config/constants.php');
    //1.Get the ID of admin to be delete
      $id =$_GET['id'];
    //2.Create SQL query to delete admin
    $sql = "DELETE FROM tbl_admin WHERE id=$id";

    //Execute the query 
    $res = mysqli_query($conn, $sql);
    
    //check wether the query executed seccessfully or not 
    if($res==true)
    {
        //Query executed successfully and admin deleted 
        //echo "Admin deleted";
        //Create session variable to display message
        $_SESSION['delete'] = "<div class='success'>Admin deleted successfully.</div>";
        //Redirect to manage-admin page
        header('location:'.SITEURL.'admin/manage-admin.php');
        ob_enf_fluch();
    }
    else
    {
        //failed to delete admin
        //echo "Failed to delete admin.";
        //3.Redirect to manage admin page with message(done or not)
        $_SESSION['delete'] = "<div class='error'> Failed to delete admin.Try again...</div>";
        header('location:'.SITEURL.'admin/manage-admin.php');
        ob_enf_fluch();
    }


?>