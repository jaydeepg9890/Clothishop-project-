<?php
     
     //include constrants.php file here
     include('../config/constants.php');
     //Check whether the ID and image name value is set or not
     if(isset($_GET['id']) AND isset($_GET['image_name']))
     {
         //Get the value and delete
         //echo "Got the value";
         $id = $_GET['id'];
         $image_name = $_GET['image_name'];

         //Remove the physical image file is available
         if($image_name!= "")
         {
             //image is available can be removed
             $path = "../images/category/".$image_name;
             //Remove the image
             $remove = unlink($path);

             //if failed to remove the image then add an error message and stop the process
             if($remove==false)
             {
                 //set the session 
                 $_SESSION['remove'] = "<div class='error'> Failed to remove categeory image.</div>";
                 //redirect to manage category page
                 header('location:'.SITEURL.'admin/manage-category.php');
                 ob_enf_fluch();
                 //Stop the process
                 die();
             }

         }

          //Delete data from datbase
          //SQL query to delete the category
          $sql = "DELETE FROM tbl_category WHERE id=$id";

          //Execute the query
          $res = mysqli_query($conn, $sql);
    
           //check wether the query executed seccessfully or not 
           if($res==true)
           {
           //Set sucess message and redirect
           $_SESSION['delete'] = "<div class='success'>Category deleted successfully.</div>";
           //Redirect to manage-admin page
           header('location:'.SITEURL.'admin/manage-category.php');
           ob_enf_fluch();
           }
           else
           {
           //Set Fail message and redirect
           $_SESSION['delete'] = "<div class='error'> Failed to delete category.</div>";
           header('location:'.SITEURL.'admin/manage-category.php');
           ob_enf_fluch();
           }

      //Redirect to manage category page with message
      }
      else
      {
      //Redirect to manage category page
      header('location:'.SITEURL.'admin/manage-category.php');
      }
    
?>