<?php include('part/menu.php'); ?>
    
     <!-- Main content section starts -->
     <div class="main-content">
       <div class="wrapper">
          <h1><i class="fas fa-chart-line"> Dashboard</i></h1>
        <br>
          <?php
                
                if(isset($_SESSION['login']))
                {
                  echo $_SESSION['login']; //Displaying the message
                  unset($_SESSION['login']); //Removing the message
                } 
          ?>
          <br></br>

          <div class="col-4 text-center">  
              <?php
                  //SQL query
                  $sql = "SELECT * FROM tbl_category";
                  //Execute the query
                  $res = mysqli_query($conn, $sql);
                  //Count the rows
                  $count = mysqli_num_rows($res);
              ?>
              <h1><?php echo $count; ?></h1>
              <br>
              Categories(Available)
          </div>    

          <div class="col-4 text-center">     
              <?php
                  //SQL query
                  $sql2 = "SELECT * FROM tbl_detail";
                  //Execute the query
                  $res2 = mysqli_query($conn, $sql2);
                  //Count the rows
                  $count2 = mysqli_num_rows($res2);
              ?>
              <h1><?php echo $count2; ?></h1> 
              <br>
              Products(Available)
          </div>    

          <div class="col-4 text-center">             
              <?php
                  //SQL query
                  $sql3 = "SELECT * FROM tbl_buy";
                  //Execute the query
                  $res3 = mysqli_query($conn, $sql3);
                  //Count the rows
                  $count3 = mysqli_num_rows($res3);
              ?>
              <h1><?php echo $count3; ?></h1> 
              <br>
              Total Orders
          </div>   

          <div class="col-4 text-center">
              <?php
                 //Create sql query to GEt total Revenue generaetd
                 //Aggreagte function in sql
                 $sql4 = "SELECT SUM(price) AS price FROM tbl_buy WHERE status='Delivered'";
                 //Execute the query
                 $res4 = mysqli_query($conn, $sql4);
                 //Count the value
                 $row4 = mysqli_fetch_assoc($res4);
                 
                 //GEt the revenue
                 $total_revenue = $row4['price'];
              
              ?> 
              <h1>$<?php echo $total_revenue; ?></h1>
              <br>
              Revenue Generated
          </div> 

          <div class="clearfix"></div>
       </div> 
     </div>
     <!-- Main section ends here -->
      
<?php include('part/footer.php'); ?>