<?php ob_start(); ?>
<?php include('../config/constants.php'); ?>
<html>
    
    <head>    
        <meta charset="utf-8">
        <title>Admin Login - Clothishop</title>
        <link rel="stylesheet" href="../css/admin4.css"> 
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://kit.fontawesome.com/a076d05399.js"></script>
        <link rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    </head>

    <body>
          
     <div class="container">
        <div class="admin-login">
          <div class="title"><span><i class="fas fa-user-cog"> Admin Login</i></span></div>
            <h1 class="text-center"><i class='bx bxs-t-shirt'></i>ClothiShop</h1>
          <?php
                
                if(isset($_SESSION['login']))
                {
                  echo $_SESSION['login']; //Displaying the message
                  unset($_SESSION['login']); //Removing the message
                }

                if(isset($_SESSION['no-login-message']))
                {
                  echo $_SESSION['no-login-message']; //Displaying the message
                  unset($_SESSION['no-login-message']); //Removing the message
                } 
                
        ?>

            <form action="" method="POST">
              <div class="row">
                <i class="fas fa-user"></i>
                <input type="text" name="username" placeholder="Username" required>
              </div>
              <div class="row">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" placeholder="Password" required>
              </div>

              <div class="row button">
               <input type="submit" name="submit" value="Login">
              </div>
              <div class="signup-link">Designed & Developed by<a href="https://www.instagram.com/mohd_azr_pvt01/"> Mohammad Azhar</a></div>
            </form>
        </div>
     </div>

    </body>
</html>

<?php
     //Check whther the submit is clicked or not
     if(isset($_POST['submit']))
     {
         //process for login
         //1.Get the data from logni from
        $username = $_POST['username'];
        $password = md5($_POST['password']);

        //2.SQL to check whther the user with username and password exists
          $sql = "SELECT * FROM tbl_admin WHERE username='$username' AND password='$password'";

        //execute the query
        $res = mysqli_query($conn , $sql);

        //4Count the rows to check whther the user exists or not
        $count = mysqli_num_rows($res);

        if($count==1)
        {
          //User is vaialable and login success
          $_SESSION['login'] = "<div class='success'>Login Sucessful.</div>";
          
          $_SESSION['user'] = $username; //to check whther the user is loged in or not and logout will unset it

          //redirect to home page dashboard
          header('location:'.SITEURL.'admin');
          ob_enf_fluch();
        }
        else
        {
          //User not available nad login failed
          $_SESSION['login'] = "<div class='error text-center'>Username or Password not matched!</div>";
          //redirect to home page dashboard
          header('location:'.SITEURL.'admin/login.php');
          ob_enf_fluch();

        }
    
    }
?>