<?php ob_start(); ?>
<?php include('../config/constants.php'); ?>
<?php 
    //including constants.php for SITEURL 
    include('../config/constants.php');
    //1. Destroy the session 
     session_destroy(); //unset the session 
    
    
    //2.Redirect to login page
    header('location:'.SITEURL.'admin/login.php');
    ob_enf_fluch();
?>