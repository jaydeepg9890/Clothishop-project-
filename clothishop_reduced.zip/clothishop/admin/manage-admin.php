<?php include('part/menu.php'); ?>   
    
     <!.. Main content section starts ..>
     <div class="main-content">
       <div class="wrapper">
          <h1><i class="fas fa-user-cog"> Manage Admin</i></h1>
            <br/>

            <?php
                if(isset($_SESSION['add']))
                {
                  echo $_SESSION['add']; //Displaying the message
                  unset($_SESSION['add']); //Removing the message
                }

                if(isset($_SESSION['delete']))
                {
                  echo $_SESSION['delete']; //Displaying the message
                  unset($_SESSION['delete']); //Removing the message
                }

                if(isset($_SESSION['user-not-found']))
                {
                  echo $_SESSION['user-not-found']; //Displaying the message
                  unset($_SESSION['user-not-found']); //Removing the message
                }
                
                if(isset($_SESSION['pwd-not-match']))
                {
                  echo $_SESSION['pwd-not-match']; //Displaying the message
                  unset($_SESSION['pwd-not-match']); //Removing the message
                } 

                if(isset($_SESSION['change-pwd']))
                {
                  echo $_SESSION['change-pwd']; //Displaying the message
                  unset($_SESSION['change-pwd']); //Removing the message
                } 

            ?>
                <br><br><br> 
             <!-- Button to add admin -->
             <a href="add-admin.php" class="btn-primary">Add Admin</a>
              <br><br><br>
          <table class="tbl-full">
              <tr>
                <th>S.no.</th>
                <th>Fullname</th>
                <th>Username</th>
                <th>Actions</th>
              </tr>

            <?php
              //Query to get all admin
              $sql = "SELECT * FROM tbl_admin";
              //Execute the query is executed or not
              $res = mysqli_query($conn, $sql);
              if($res==TRUE)
              {
                // count rows to check whether we have data in database or not
                $count = mysqli_num_rows($res); //Function to get all the rows in database
             
                $sn=1; //Creating a variable and assigning the a value 

                //check the number of rows
                if($count>0)
                {
                  //we have data in database
                  while($rows=mysqli_fetch_assoc($res))
                  {
                    //Using while loop to get all the data from database
                    //and while loop will run as long as we have data in database

                    //get individual data
                    $id=$rows['id'];
                    $full_name=$rows['full_name'];
                    $username=$rows['username'];

                    //Displaying the values in our table
                    ?>
              <tr>
                 <td><?php echo $sn++; ?></td>
                 <td><?php echo $full_name; ?></td>
                 <td><?php echo $username; ?></td>
                 <td>
                    <a href="<?php echo SITEURL; ?>admin/change-password.php?id=<?php echo $id; ?>" class="btn-pass">Change Password</a>
                    <a href="<?php echo SITEURL; ?>admin/delete-admin.php?id=<?php echo $id; ?>" class="btn-danger">Delete Admin</a>
                </td>
              </tr> 



                    <?php
                  }
                }
                else
                {
                  //We don't have data in database
                }

              }



            ?>
           </table> 
       </div> 
     </div>
     <!.. Main section ends here ..>
      
<?php include('part/footer.php'); ?>