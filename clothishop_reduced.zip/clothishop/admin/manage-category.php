<?php include('part/menu.php'); ?>

 <div class="main-content">
   <div class="wrapper">
    <h1><i class="fas fa-align-left"> Manage Category</i></h2>
       
       <br/><br/>
            <?php
                if(isset($_SESSION['add'])) //cheking whether the session is set or not
                {
                  echo $_SESSION['add']; //Displaying the message if SET
                  unset($_SESSION['add']); //Removing the message
                }

                if(isset($_SESSION['remove'])) //cheking whether the session is set or not
                {
                  echo $_SESSION['remove']; //Displaying the message if SET
                  unset($_SESSION['remove']); //Removing the message
                }

                if(isset($_SESSION['delete']))
                {
                  echo $_SESSION['delete']; //Displaying the message
                  unset($_SESSION['delete']); //Removing the message
                }

                if(isset($_SESSION['no-category-found']))
                {
                  echo $_SESSION['no-category-found']; //Displaying the message
                  unset($_SESSION['no-category-found']); //Removing the message
                }

                if(isset($_SESSION['update']))
                {
                  echo $_SESSION['update']; //Displaying the message
                  unset($_SESSION['update']); //Removing the message
                }

                if(isset($_SESSION['upload']))
                {
                  echo $_SESSION['upload']; //Displaying the message
                  unset($_SESSION['upload']); //Removing the message
                }

                if(isset($_SESSION['failed-remove']))
                {
                  echo $_SESSION['failed-remove']; //Displaying the message
                  unset($_SESSION['failed-remove']); //Removing the message
                }



            ?>
       <br><br> 

     <a href="<?php echo SITEURL; ?>admin/add-category.php" class="btn-primary">Add Category</a>
              <br/><br>
              <br/>
          <table class="tbl-full">
              <tr>
                <th>S.no.</th>
                <th>Title</th>
                <th>Image</th>
                <th>Featured</th>
                <th>Active</th>
                <th>Actions</th>          
              </tr>
 
              <?php
                  
                  //Query to get all categories data from database
                  $sql = "SELECT * FROM tbl_category";
                  
                  //Execute the query
                  $res = mysqli_query($conn, $sql);

                  //Count the rows
                  $count = mysqli_num_rows($res);

                  //create serial no with assigning a vriable
                  $sn=1;


                  //Check whther we have data in database or not
                  if($count>0)
                  {
                    //We have data in databse
                    //GEt the data 
                    while($row=mysqli_fetch_assoc($res))
                    {
                       $id = $row['id'];
                       $title = $row['title'];
                       $image_name = $row['image_name'];
                       $featured = $row['featured'];
                       $active = $row['active'];


                    ?>
                    <tr>
                       <td><?php echo $sn++; ?></td>
                       <td><?php echo $title; ?></td>

                       <td>
                       <?php

                         //Check wether image name is available or not
                         if($image_name!="")
                         {
                           //We have image
                           //Display the image
                           ?>

                           <img src="<?php echo SITEURL; ?>images/category/<?php echo $image_name; ?>" width="130px" >

                           <?php
                         }
                         else
                         {
                           //we do not have image
                           //Display the message
                           echo "<div class='error'>Image not added.</div>";
                         }
                        
                       ?>
                       </td>

                       <td><?php echo $featured; ?></td>
                       <td><?php echo $active; ?></td>
                       <td>
                          <a href="<?php echo SITEURL; ?>admin/update-category.php?id=<?php echo $id; ?>" class="btn-secondary">Update Catgeory</a>
                          <a href="<?php echo SITEURL; ?>admin/delete-category.php?id=<?php echo $id; ?>&image_name=<?php echo $image_name; ?>" class="btn-danger">Delete Catgory</a>
                       </td>
                     </tr> 




                     <?php
                    }

                  }
                  else
                  {
                    //WE do not have data database
                    //We will display the message inside trhe table
                    ?>

                    <tr>
                        <td colspan="6"><div class="error">No category added.</div></td>
                    </tr>

                    <?php

                  }


              ?>

           </table> 
   </div>
</div>



<?php include('part/footer.php'); ?>