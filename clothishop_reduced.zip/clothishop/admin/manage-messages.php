<?php include('part/menu.php'); ?>   

     <!--Main content section starts -->
     <div class="main-content">
       <div class="wrapper">
          <h1><i class="fas fa-envelope-open-text"> Messages</i></h1>
            <br/>

            <?php

                if(isset($_SESSION['delete']))
                {
                  echo $_SESSION['delete']; //Displaying the message
                  unset($_SESSION['delete']); //Removing the message
                }

            ?>
                <br><br><br> 
             <!-- Button to add admin -->
          <table class="tbl-full">
              <tr>
                <th>S.no.</th>
                <th>Name</th>
                <th>E-mail</th>
                <th>Message</th>
                <th>Actions</th>
              </tr>

            <?php
              //Query to get all admin
              $sql = "SELECT * FROM tbl_contact_us";
              //Execute the query is executed or not
              $res = mysqli_query($conn, $sql);
              if($res==TRUE)
              {
                // count rows to check whether we have data in database or not
                $count = mysqli_num_rows($res); //Function to get all the rows in database
             
                $sn=1; //Creating a variable and assigning the a value 

                //check the number of rows
                if($count>0)
                {
                  //we have data in database
                  while($rows=mysqli_fetch_assoc($res))
                  {
                    //Using while loop to get all the data from database
                    //and while loop will run as long as we have data in database

                    //get individual data
                    $id = $rows['id'];
                    $full_name = $rows['full_name'];
                    $email = $rows['email'];
                    $message = $rows['message'];

                    //Displaying the values in our table
                    ?>
              <tr>
                 <td><?php echo $sn++; ?></td>
                 <td><?php echo $full_name; ?></td>
                 <td><?php echo $email; ?></td>
                 <td><?php echo $message; ?></td>
                 <td>
                    <a href="<?php echo SITEURL; ?>admin/delete-message.php?id=<?php echo $id; ?>" class="btn-danger">Delete Message</a>
                    <a href="mailto:<?php echo $email; ?>" class="btn-secondary">Respond to User</a>
                    
                </td>
              </tr> 



                    <?php
                  }
                }
                else
                {
                  //We don't have data in database
                }

              }



            ?>
           </table> 
       </div> 
     </div>
     <!-- Main section ends here -->
      
   <?php include('part/footer.php'); ?>