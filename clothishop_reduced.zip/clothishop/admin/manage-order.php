<?php include('part/menu.php'); ?>

<div class="main-content">
     <div class="wrapper">
       <h1><i class="fas fa-archive"> Manage Order</i></h2>
        <br/></br><br> 
         
        <?php
           if(isset($_SESSION['update']))
           {
             echo $_SESSION['update']; //Displaying the message
             unset($_SESSION['update']); //Removing the message
           }           

           if(isset($_SESSION['delete']))
           {
             echo $_SESSION['delete']; //Displaying the message
             unset($_SESSION['delete']); //Removing the message
           }           
        ?>

       <table class="tbl-full">
              <tr>
                <th>S.no. </th>
                <th>Product Code</th>
                <th>Product </th>
                <th>Price </th>
                <th>Order Date </th>
                <th>Status </th>
                <th>Customer name </th>
                <th>Customer Contact </th>
                <th>Customer Email </th>
                <th>House no. </th>
                <th>Area </th>
                <th>Landmark </th>
                <th>City </th>
                <th>Pincode </th>
                <th>State </th>
                <th>Country </th>
                <th>Actions </th>
              </tr>

              <?php
                  //Get all the orders from databse
                  $sql = "SELECT * FROM tbl_buy ORDER BY id DESC";//USing DESC to display the latest order

                  //Execute the query
                  $res = mysqli_query($conn, $sql);

                  //Count th rows
                  $count = mysqli_num_rows($res);

                  //Creating a variable to initializing th eseries with 1
                  $sn = 1;

                  if($count>0)
                  {
                    //Oredr available
                    while($row=mysqli_fetch_assoc($res))
                    {
                      //Get all the details of order
                      $id = $row['id'];
                      $product = $row['product'];
                      $product_code = $row['product_code'];
                      $price = $row['price'];
                      $order_date = $row['order_date'];
                      $status = $row['status'];
                      $customer_name = $row['customer_name'];
                      $customer_contact = $row['customer_contact'];
                      $customer_email = $row['customer_email'];
                      $country = $row['country'];
                      $state = $row['state'];
                      $city = $row['city'];
                      $pincode = $row['pincode'];
                      $landmark = $row['landmark'];
                      $area = $row['area'];
                      $house_no = $row['house_no'];
                      ?>
                         
                      <tr>
                       <td><?php echo $sn++; ?></td>
                       <td><?php echo $product_code; ?></td>
                       <td><?php echo $product; ?></td>
                       <td><?php echo $price; ?></td>
                       <td><?php echo $order_date; ?></td>
                       
                       <td>
                           <?php
                              //Ordered,on delivery and delivered, cancelled color indication

                              if($status=="Ordered")
                              {
                                echo "<label>$status</label>";
                              }
                              else if($status=="On Delivery")
                              {
                                echo "<label style='color: green;'>$status</label>";
                              }
                              else if($status=="Delivered")
                              {
                                echo "<label style='color: orange;'>$status</label>";
                              }
                              else if($status=="Cancelled")
                              {
                                echo "<label style='color: red;'>$status</label>";
                              }
                           ?>
                       </td>

                       <td><?php echo $customer_name; ?></td>
                       <td><?php echo $customer_contact; ?></td>
                       <td><?php echo $customer_email; ?></td> 
                       <td><?php echo $house_no; ?></td>
                       <td><?php echo $area; ?></td>
                       <td><?php echo $landmark; ?></td>
                       <td><?php echo $city; ?></td>
                       <td><?php echo $pincode; ?></td>
                       &nbsp;&nbsp;&nbsp;<td><?php echo $state; ?></td>
                       <td><?php echo $country; ?></td>

                       <td>
                            <a href="<?php echo SITEURL; ?>admin/update-order.php?id=<?php echo $id; ?>" class="btn-secondary">Update Order</a>
                            <a href="<?php echo SITEURL; ?>admin/delete-order.php?id=<?php echo $id; ?>" class="btn-danger">Delete Order</a>
                        </td>
                      </tr>

                      <?php

                    }
                  }
                  else
                  {
                    //Order not available
                    echo "<tr><td colspan='12' class='error'>Orders not available.</td></tr>";
                  }


              ?>  


        </table> 
     </div>
  </div>

  <?php include('part/footer.php'); ?>