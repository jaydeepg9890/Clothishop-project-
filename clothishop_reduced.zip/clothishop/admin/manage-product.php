<?php include('part/menu.php'); ?>
  <div class="main-content">
     <div class="wrapper">
       <h1><i class='bx bxs-t-shirt'></i> Manage Products</h2>
     <!-- Button to add category -->
        <br><br>
         <?php
              if(isset($_SESSION['add'])) //cheking whether the session is set or not
              {
                echo $_SESSION['add']; //Displaying the message if SET
                unset($_SESSION['add']); //Removing the message
              } 

              if(isset($_SESSION['remove'])) //cheking whether the session is set or not
              {
                echo $_SESSION['remove']; //Displaying the message if SET
                unset($_SESSION['remove']); //Removing the message
              }

              if(isset($_SESSION['delete']))
              {
                echo $_SESSION['delete']; //Displaying the message
                unset($_SESSION['delete']); //Removing the message
              }

              if(isset($_SESSION['unauthorized']))
              {
                echo $_SESSION['unauthorized']; //Displaying the message
                unset($_SESSION['unauthorized']); //Removing the message
              }

              if(isset($_SESSION['upload']))
              {
                echo $_SESSION['upload']; //Displaying the message
                unset($_SESSION['upload']); //Removing the message
              }
              
              if(isset($_SESSION['failed-remove']))
              {
                echo $_SESSION['failed-remove']; //Displaying the message
                unset($_SESSION['failed-remove']); //Removing the message
              }

              if(isset($_SESSION['update']))
              {
                echo $_SESSION['update']; //Displaying the message
                unset($_SESSION['update']); //Removing the message
              }          

         ?> 
          <br><br>
          <a href="<?php echo SITEURL; ?>admin/add-product.php" class="btn-primary">Add Product</a>
          <br><br>
          <br>
          
          <table class="tbl-full">
              <tr>
                <th>S.no.</th>
                <th>Title</th>
                <th>Product Code</th>
                <th>Price</th>
                <th>Delivery</th>
                <th>Size</th>
                <th>Image</th>
                <th>Featured</th>
                <th>Active</th>
                <th>Actions</th>
              </tr>

              <?php
                  //Create SQL query to get all the product
                  $sql = "SELECT * FROM tbl_detail";

                  //Execute the query
                  $res = mysqli_query($conn, $sql);

                  //Count rows to check wthether we have have food or not
                  $count = mysqli_num_rows($res);
                  
                  //Creating a veariable for number seiries
                  $sn=1;

                  if($count>0)
                  {
                    //We haev food in database
                    //EGt the foods from database and display
                    while($row=mysqli_fetch_assoc($res))
                    {
                      //Get the values from colunms
                      $id = $row['id'];
                      $title = $row['title'];
                      $product_code = $row['product_code'];
                      $price = $row['price'];
                      $delivery = $row['delivery'];
                      $size = $row['size'];
                      $image_name1 = $row['image_name1'];
                      $featured = $row['featured'];
                      $active = $row['active'];
                      ?>

                      <tr>
                         <td><?php echo $sn++; ?>.</td>
                         <td><?php echo $title; ?></td>
                         <td><?php echo $product_code; ?></td>
                         <td>Rs<?php echo $price; ?></td>
                         <td>Rs<?php echo $delivery; ?></td>
                         <td><?php echo $size; ?></td>
                         <td>
                            <?php   
                             //Check wether image name is available or not
                             if($image_name1!="")
                             {
                               //We have image
                               //Display the image
                               ?>

                               <img src="<?php echo SITEURL; ?>images/products/<?php echo $image_name1; ?>" width="130px" >

                               <?php
                             }
                             else
                             {
                               //we do not have image
                               //Display the message
                               echo "<div class='error'>Image not added.</div>";
                             }
                        
                            ?>

                         </td>
                         <td><?php echo $featured; ?></td>
                         <td><?php echo $active; ?></td>
                         <td>
                            <a href="<?php echo SITEURL; ?>admin/update-product.php?id=<?php echo $id; ?>" class="btn-secondary">Update Product</a>
                            <a href="<?php echo SITEURL; ?>admin/delete-product.php?id=<?php echo $id; ?>&image_name1=<?php echo $image_name1; ?>" class="btn-danger">Delete Product</a>
                         </td>
                      </tr> 

                      <?php

                    }

                  }
                  else
                  {
                    //product not added in database
                    echo "<tr> <td colspan='7' class='error'> products not added yet.</td></tr>";
                  }

              ?>

          </table> 
      </div>
  </div>

  <?php include('part/footer.php'); ?>