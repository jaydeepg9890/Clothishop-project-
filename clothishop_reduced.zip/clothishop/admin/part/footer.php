<!.. Footer section starts ..> 
     <div class="footer">
       <div class="wrapper">
          <p class="text-center">All rights reserved by Clothishop developed by -<a href="#"> </a> .
       </div>   
     </div>
     <!footer section ends ..>
    </body>   
</html>