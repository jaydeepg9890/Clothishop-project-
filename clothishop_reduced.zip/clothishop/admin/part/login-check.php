<?php include('../config/constants.php'); ?>
<?php
   //Authorization : access control
   //Check Wether the user is logged in or not
   if(!isset($_SESSION['user']))    //if user session is set
   {
       //User is not loged in
       //Redirect to log in page with message 
       
       $_SESSION['no-login-message'] = "<div class='error text-center'>Login to Access the Panel.</div>";
       //redirect to home page dashboard
       header('location:'.SITEURL.'admin/login.php');
 
   }

?>