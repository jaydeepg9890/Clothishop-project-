<?php ob_start(); ?>

<?php include('login-check.php'); ?>
<html>
    <head>
      <title> Admin side login | Clothishop</title>
      <link rel="stylesheet" href="../css/admin1.css">
      
      <!-- Favicon icons-->
      <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
      <link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
      <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
      <link rel="manifest" href="site.webmanifest">
      
      <link rel="stylesheet" type="css/text" href="css/all.min.css">
      <script src="https://kit.fontawesome.com/a076d05399.js"></script>
      <link rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    </head>  

    <body>
     <!-- Menu section starts -->
     <div class="Menu">
       <div class="wrapper">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="manage-admin.php">Admin</a></li>
            <li><a href="manage-category.php">Category</a></li>
            <li><a href="manage-product.php">Products</a></li>
            <li><a href="manage-gallery.php">Gallery</a></li>
            <li><a href="manage-order.php">Order</a></li>
            <li><a href="manage-user.php">User</a></li>
            <li><a href="manage-messages.php">Messages</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
       </div>    
     </div>  
     <!--Menu section ends -->