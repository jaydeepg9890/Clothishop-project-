<?php include('part/menu.php'); ?>

<div class="main-content">
      <div class="wrapper">
          <h1>Update Order</h1>
        
        <br><br>
        <?php
        //Ceheck whether the id is set or not
        if(isset($_GET['id']))
        {
            //GEt the order details
            $id = $_GET['id'];

            //Get all other details
            //SQL query to get all thg edetail of order
            $sql = "SELECT * FROM tbl_buy WHERE id=$id";

            //Execute the query 
            $res = mysqli_query($conn, $sql);

            //count the rows
            $count = mysqli_num_rows($res);

            if($count==1)
            {
                //Details available

                //GEt all the details from the data base
                $row = mysqli_fetch_assoc($res);

                $products = $row['product'];
                $price = $row['price'];
                $product_code = $row['product_code'];
                //$color = $row['color'];
                //$size = $row['size'];
                $order_date = $row['order_date'];
                $status = $row['status'];
                $customer_name = $row['customer_name'];
                $customer_contact = $row['customer_contact'];
                $customer_email = $row['customer_email'];
                $country = $row['country'];
                $state = $row['state'];
                $city = $row['city'];
                $pincode = $row['pincode'];
                $landmark = $row['landmark'];
                $area = $row['area'];
                $house_no = $row['house_no'];

            }
            else
            {
                //Deatils not available
                //REdirect to manage order 
                header('location:'.SITEURL.'admin/manage-order.php');

            }

        }
        else
        {
            //Redirect to manage Order page
            header('location:'.SITEURL.'admin/manage-order.php');
        }
        
        ?>

      <form action="" method="POST">

            <table class="tbl-30">

                 <tr>
                    <td>Product name: </td>
                    <td><b> <?php echo $mineral; ?> </b> </td>
                 </tr>

                 <tr>
                    <td>Product code: </td>
                    <td><b> <?php echo $mineral_code; ?> </b> </td>
                  </tr>
                    
                 <tr>
                    <td>Price: </td>
                    <td><b> <?php echo $price; ?> </b> </td>  
                 </tr>

                 <tr>
                    <td>Status: </td>
                    <td>
                        <select name="status">
                               <option <?php if($status=="ordered"){echo "selected"; } ?> value="Ordered">Ordered</option>
                               <option <?php if($status=="On Delivery"){echo "selected"; } ?> value="On Delivery">On Delivery</option>
                               <option <?php if($status=="Delivered"){echo "selected"; } ?> value="Delivered">Delivered</option>
                               <option <?php if($status=="Cancelled"){echo "selected"; } ?> value="Cancelled">Cancelled</option>
                        </select>       
                    </td>
                 </tr>
                  
                 <tr>
                    <td>Customer Name: </td>
                    <td>
                       <input type="text" name="customer_name" value="<?php echo $customer_name; ?>">
                    </td>    
                 </tr>

                 <tr>
                    <td>Customer Contact: </td>
                    <td>
                       <input type="text" name="customer_contact" value="<?php echo $customer_contact; ?>">
                    </td>   
                 </tr>

                 <tr>
                    <td>Customer Email: </td>
                    <td>
                       <input type="text" name="customer_email" value="<?php echo $customer_email; ?>">
                    </td>    
                 </tr>

                 <tr>
                    <td colspan="2">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <input type="hidden" name="price" value="<?php echo $price; ?>">
                        <input type="submit" name="submit" value="Upadate Order" class="btn-secondary">
                    </td>
                 </tr>

            </table>
       </form>

       <?php
       //Updating the detials of order
          if(isset($_POST['submit']))
        {
          //echo "clicked";
          //1.Get all the values from form
          $id = $_POST['id'];
          $product = $_POST['product'];
          $price = $_POST['price'];
          $product_code = $_POST['product_code'];

          $status = $_POST['status']; 

          $customer_name = $_POST['customer_name'];
          $customer_contact = $_POST['customer_contact'];
          $customer_email = $_POST['customer_email'];

          //Update the values
          $sql2 = "UPDATE tbl_buy SET
              status = '$status'
              WHERE id=$id
          ";

          //Execute the query
          $res2 = mysqli_query($conn, $sql2);

          //Check whther the order is upadted is or not
          //And redireect to manage order  page
          if($res2==true)
          {
             //ORder Updated
             $_SESSION['update'] = "<div class='success'>Order updated seccessfully.</div>";
            header('location:'.SITEURL.'admin/manage-order.php');

          }
          else
          {
             //Failed to updaet the order
             //failed to update the category
            $_SESSION['update'] = "<div class='error'>Failed to upadate order.</div>";
            header('location:'.SITEURL.'admin/manage-order.php');

          }
        }
      ?>

      </div>
</div>          

<?php include('part/footer.php'); ?>