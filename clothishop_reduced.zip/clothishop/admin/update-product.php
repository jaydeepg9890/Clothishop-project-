<?php include('part/menu.php'); ?>

  <div class="main-content">
      <div class="wrapper">
          <h1>Update Product</h1>
          
          <br><br>

      <?php
        //Check whther the id is set or not
        if(isset($_GET['id']))
        {
            //Get the ID and all other data
            $id = $_GET['id'];

            //Create SQL query to get all other detail
            $sql2 = "SELECT * FROM tbl_detail WHERE id=$id";

            //Execute the query 
            $res2 = mysqli_query($conn, $sql2);

            //Get all the data
            $row2 = mysqli_fetch_assoc($res2);
                
            //Get the individual values of selected food 
            $title = $row2['title'];
            $product_code = $row2['product_code'];
            $description = $row2['description'];
            $price = $row2['price'];
            $delivery = $row2['delivery'];
            $size = $row2['size'];
            $color = $row2['color'];
            $current_image = $row2['image_name1'];
            $type = $row2['ftype'];
            $category_name = $row2['category_name'];
            $shipping_area = $row2['shipping_area'];
            $current_category = $row2['category_id'];
            $featured = $row2['featured'];
            $active = $row2['active'];


        }
        else
        {
            //Redirect to manage product
            header('location:'.SITEURL.'admin/manage-product.php');
        }

      ?>   

          <form action="" method="POST" enctype="multipart/form-data">

             <table class="tbl-30">
                 <tr>
                    <td>Title:</td>
                    <td>
                       <input type="text" name="title" value="<?php echo $title; ?>">
                    </td>
                 </tr>

                 <tr>
                    <td>product code:</td>
                    <td>
                       <?php echo $product_code; ?>
                    </td>
                 </tr>
                
                 <tr>
                    <td>Description:</td>
                    <td>
                       <textarea name="description" cols="30" rows="5"><?php echo $description; ?></textarea>
                    </td>
                 </tr>

                 <tr>
                    <td>Price:</td>
                    <td>
                       <input type="number" name="price" value="<?php echo $price; ?>">
                    </td>
                 </tr>

                 <tr>
                    <td>Delivery Charges:</td>
                    <td>
                       <input type="number" name="delivery_charges" value="<?php echo $delivery; ?>">
                    </td>
                 </tr>

                 <tr>
             <td>Current Image: </td>
             <td>
                 <?php
                     if($current_image =="")
                     {
                         //image not available
                         //Displaying the message
                         echo "<div class='error'>Image not added.</div>"; 
                        
                     }
                     else
                     {
                         //image available
                         //Displaying the message
                         ?>
                         <img src="<?php echo SITEURL; ?>images/products/<?php echo $current_image; ?>" width="150px">
                        <?php 
                     }
                 ?>
             </td>
          </tr>

          <tr>
             <td>Select New Image: </td>
             <td>
               <input type="file" name="image">
             </td>
          </tr>

          <tr>
             <td>Category: </td>
             <td>
                <select name="category">
                     
                     <?php
                                //Create php code to display categories from database
                                //1.Create SQL query to get all active categories from database
                                $sql = "SELECT *FROM tbl_category WHERE active='YES'";

                                $res = mysqli_query($conn, $sql);

                                //Count rows to whether we have categories
                                $count = mysqli_num_rows($res);
                                
                                //Check whether category available or not
                                if($count>0)
                                {
                                    //we have categeories
                                    while($row=mysqli_fetch_assoc($res))
                                    {
                                        $category_title = $row['title'];
                                        $category_id = $row['id'];
                                        
                                        ?>
                                        <option <?php if($current_image==$category_id){echo "selected";} ?> value="<?php echo $category_id; ?>"><?php echo $category_title; ?></option>
                                        <?php
                                    
                                    }
                                } 
                                else
                                {
                                    //We dont have category                                    
                                    echo "<option value='0'>No category available.</option>";
                  
                                }


                     ?>
                </select>
             </td>   
           </tr>

           <tr>
              <td>Fabric Type:</td>
              <td>
              <input type="text" name="type" value="<?php echo $type; ?>">
              </td>
           </tr>

           <tr>
              <td>Size:</td>
              <td>
              <input type="text" name="size" value="<?php echo $size; ?>">
              </td>
           </tr>

           <tr>
              <td>Color:</td>
              <td>
              <input type="text" name="color" value="<?php echo $color; ?>">
              </td>
           </tr>

           <tr>
              <td>Category Name:</td>
              <td>
              <input type="text" name="category_name" value="<?php echo $category_name; ?>">
              </td>
           </tr>

           <tr>
              <td>Shipping Area:</td>
              <td>
              <input type="text" name="shipping_area" value="<?php echo $shipping_area; ?>">
              </td>
           </tr>

          <tr>
             <td>Featured: </td>
             <td>
             <input <?php if($featured == "YES"){echo "checked";}?> type="radio" name="featured" value="YES">YES
             <input <?php if($featured == "NO"){echo "checked";}?>  type="radio" name="featured" value="NO">NO
             </td>
          </tr>

          <tr>
             <td>Active:</td>
             <td>
               <input <?php if($active == "YES"){echo "checked";}?> type="radio" name="active" value="YES">YES
               <input <?php if($active == "NO"){echo "checked";}?> type="radio" name="active" value="NO">NO
             </td>
          </tr>          

         <tr>
            <td>
                <input type="hidden" name="current_image" value="<?php echo $current_image; ?>">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <input type="submit" name="submit" value="Update product" class="btn-secondary">
            </td>
         </tr>

             </table>
          </form>
       <?php
          if(isset($_POST['submit']))
        {
          //echo "clicked";
          //1.Get all the values from form
          $id = $_POST['id'];
          $title = $_POST['title'];
          $description = $_POST['description'];
          $price = $_POST['price'];
          $delivery = $_POST['delivery_charges'];
          $current_image = $_POST['current_image'];
          $category = $_POST['category'];
          $type = $_POST['type'];
          $color = $_POST['color'];
          $size = $_POST['size'];
          $shipping_area = $_POST['shipping_area'];
          $category_name = $_POST['category_name'];
          $featured = $_POST['featured'];
          $active = $_POST['active'];

          //2.Updating new image if selected
          //Check whether the image is selected or not
          if(isset($_FILES['image']['name']))
          {
             //Get the image detail
             $image_name = $_FILES['image']['name'];

             //Check Whether the iamge is available or not
             if($image_name !="")
             {
                 //Image is avialable
                 //i)Uplaod the image
                 //Auto rename our page 
                 //Get the extension of our image (jpg,png,gif,etc) for example: "product.jpg"
                 $ext = end(explode('.', $image_name));

                 //Rename the image name
                  $image_name = "product_name_".rand(000, 999).'.'.$ext; // for example "product_category_987.pjg"
                  


                  $source_path = $_FILES['image']['tmp_name'];

                  $destination_path = "../images/products/".$image_name;
 
                  //final stage to Upload the image
                  $upload = move_uploaded_file($source_path, $destination_path);

                  //Check whether the image is uploaded is not
                  //and if the image is not uplaoded thene we will stop the process and redirect with eroor message
                  if($upload==false)
                  {
                      //Set message
                      $_SESSION['upload'] = "<div class='error'>Failed to upload the image.</div>";
                      //Redirec tto manage food page 
                      header("location:".SITEURL.'admin/manage-product.php');
                      //stop the process
                      die();
                  }
                  //3.Remove the image if new image is uploaded and current image exists 
                  //ii)Remove the current image if available
                  if($current_image != "")
                  {
                      $remove_path = "../images/products/".$current_image;

                      $remove = unlink($remove_path);

                      //Check whther the image is removes or not
                      //And if removed then display the message and stop the process
                     if($remove==false)
                     {
                        //Failed to remove image
                        $_SESSION['failed-remove'] = "<div class='error'>Failed to remove the image.</div>";
                        //REdirect to manage food
                        header('location:'.SITEURL.'admin/manage-product.php');
                        //stop the prcess
                        die();                       
                     }
                  }
             }
             else
             {
             $image_name = $current_image;
             }
          }  
          else
          {
            $image_name = $current_image;
          }
          
          //4.Upadte the product in database
          $sql3 = "UPDATE tbl_detail SET
              title = '$title',
              description = '$description',
              price = $price,
              delivery = $delivery,
              image_name1 = '$image_name',
              category_id = '$category',
              ftype = '$type',
              size = '$size',
              color = '$color',
              category_name = '$category_name',
              shipping_area = '$shipping_area',
              featured = '$featured',
              active = '$active'
               WHERE id=$id
              ";

          //Execute the query
          $res3 = mysqli_query($conn, $sql3);

          //4.Redirect to manage category with message
          //Check whether query is sexecuted or not
          if($res3==true)
          {
            //Category updated
            $_SESSION['update'] = "<div class='success'>product updated seccessfully.</div>";
            header('location:'.SITEURL.'admin/manage-product.php');
          }
          else
          {
            //failed to update the category
            $_SESSION['update'] = "<div class='error'>Failed to upadate product.</div>";
            header('location:'.SITEURL.'admin/manage-product.php');
          }

          
        }
       ?>

      </div>
  </div>

<?php include('part/footer.php'); ?>