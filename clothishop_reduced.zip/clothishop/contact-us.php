<?php include('part-front/menu.php'); ?>
<section class="contact-us-section">
 <div class="map-marking">
    <div class="map">
    <h2>Map Marking</h2>
 <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3752.0276746789505!2d75.32628636483494!3d19.881053286631168!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bdb986d68e003f9%3A0xd57983f4018f565!2sPaithan%20Gate%2C%20Aurangabad%2C%20Maharashtra%20431001!5e0!3m2!1sen!2sin!4v1652986979966!5m2!1sen!2sin" width="800" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    </div>
 </div>
<div class="contact-us">
 <div class="contact-us-container">
    <div class="contact-us-content">
       <div class="left-side">
          <div class="address detail">
             <i class="fas fa-map-marker-alt"></i>
             <div class="topic">Address</div>
             <div class="text-one">01, Vaidnaath Building,</div>
             <div class="text-one">Paithan Gate</div>
             <div class="text-two">Auranagabad 431001</div>
          </div>

          <div class="phone detail">
             <i class="fas fa-phone-alt"></i>
             <div class="topic">phone</div>
             <div class="text-one">+91-9878776766</div>
             <div class="text-two">+91-9099898787</div>
          </div>

          <div class="email detail">
             <i class="fas fa-envelope"></i>
             <div class="topic">Email</div>
             <div class="text-one">clothishop@gmail.com</div>
          </div>
       </div>

       <div class="right-side">

          <div class="topic-text">Send us a Message</div>
          <p>If you have any query related to our Minerals or services so you can send us a message,we will try to solve your query as soon as possible.</p>

       <form action="" method="POST">
           <div class="input-box">
              <input type="text" name="full_name" placeholder="Enter your full name" required>
           </div>  

           <div class="input-box">
              <input type="email" name="email" placeholder="Enter your Email" required>
           </div>

           <div class="input-box message-box">
              <textarea name="message" placeholder="Message" required></textarea>
           </div>

           <div class="send-now-btn">
              <input type="submit" name="submit" value="Submit">
           </div>
        </form>   
    </div>
     </div>
 </div>
</div>
 
</section>
<?php
     //process the value from form and save it in database.

     //check wether the submit button is clicked or not.

     if(isset($_POST['submit']))
     {
         // button clicked.
         //echo "button clicked";
     
         //1.Get the data from form
         $full_name = $_POST['full_name'];
         $email = $_POST['email'];
         $message = $_POST['message']; 

         //2.sql query to save the sata into database.
         $sql = "INSERT INTO tbl_contact_us SET
           full_name='$full_name',
           email='$email',
           message='$message'
         ";

        //3.Executing the query and saving data into database 
        $res = mysqli_query($conn, $sql) or die(mysql_error());
  
        //4.check wether the query is executed data is inserted or not and display appropriate message.
        if($res==TRUE)
        {
           //data inserted
           //create a session variable to display the message
           $_SESSION['msg-sent'] = "<div class='success text-center'>Message sent.We will response you as soon as possible.</div>";
           //redirect page to manage admin
           header("location:".SITEURL);
           ob_enf_fluch();
        } 
        else
        {
           //Data is not inserted
           //create a session variable to display the message
           $_SESSION['mesg-not-sent'] = "<div class='error text-center'>Message failed to send.</div>";
           //redirect page to add admin page
           header("location:".SITEURL);
           ob_enf_fluch();
        } 
  
     }     
         
 ?>

<?php include('part-front/footer.php'); ?>