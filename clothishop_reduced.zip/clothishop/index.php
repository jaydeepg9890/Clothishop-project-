<?php include('part-front/menu.php'); ?> 


<!-- slide show starts from here-->
<div class="slideshow-container">
      <div class="mySlides fade">

          <div class="numbertext">1/3</div>
           <img src="images/slide images/slide8.jpg" style="width: 100%">
           <div class="text">
             <p>Welcome To 
                 <br><span>Clothishop</span></p>
           </div>
          </div>
      
      <div class="mySlides fade">
          <div class="numbertext">3/3</div>
          <img src="images/slide images/slide9.jpg" style="width: 100%">
      </div>
      
      <div class="mySlides fade">
          <div class="numbertext">2/3</div>
          <img src="images/slide images/slide10.jpg" style="width: 100%">
      </div>
    
      <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
      <a class="next" onclick="plusSlides(1)">&#10095;</a>
</div> 
 <br>
 <div style="text-align:center">
       <span class="dot" onclick="currentSlide(1)"></span>
       <span class="dot" onclick="currentSlide(2)"></span>
       <span class="dot" onclick="currentSlide(3)"></span>
  </div>      


   <!-- slide show ends from here-->
   
       <?php
         if(isset($_SESSION['order']))
         {
             echo $_SESSION['order'];
             unset($_SESSION['order']);
         }  

         if(isset($_SESSION['login']))
         {
             echo $_SESSION['login']; //Displaying the message
             unset($_SESSION['login']); //Removing the message
         }
         
         if(isset($_SESSION['msg-sent']))
         {
          echo $_SESSION['msg-sent'];
          unset($_SESSION['msg-sent']);
         }  

         if(isset($_SESSION['mesg-not-sent']))
         {
          echo $_SESSION['mesg-not-sent'];
          unset($_SESSION['mesg-not-sent']);
         }  

       ?>

   <!--Category section starts from here-->
   <div class="category">
     <h2 class="text-center">Featured Categories</h2>
     <div class="category-section">

     <?php
                //Create SQL query to display categories from databse
                $sql ="SELECT * FROM tbl_category WHERE active='YES' AND featured='YES'";

                //Executre the query
                $res = mysqli_query($conn, $sql);

                //count rows to check whther the category is available or not
                $count = mysqli_num_rows($res);

                if($count>0)
                {
                 //Catgeproes available
                    
                     while($row=mysqli_fetch_assoc($res))
                     {

                       $id = $row['id'];
                       $title = $row['title'];
                       $image_name = $row['image_name'];
                       
                       ?>
                             
                          <a href="<?php echo SITEURL; ?>category-product.php?category_id=<?php echo $id; ?>">
                          <div class="c-cards">
                                 <?php
                                     if($image_name=="")
                                     {
                                         //Display message
                                         echo "<div class='error'>Image not available</div>";
                                     }
                                     else
                                     {
                                         //Image available
                                         ?>
                                         <img src="<?php echo SITEURL; ?>images/category/<?php echo $image_name; ?>" alt="<?php $image_name; ?>">
                                         <?php
                                     }
                                 ?>
                               
                              <div class="content"> 
                                 <h3><?php echo $title; ?></h3>
                              </div>
                          </div>
                          </a>
                         <?php    
                      }
                }
                else
                {
                    //Categories not available
                    echo "<div class='error'>Category not added.</div>";
                }

            ?>
        </div>
<!-- Categories section ends from here-->
         

<!-- Porduct menu stars from here-->
 <div class="product-menu">
     <h2 class="text-center">Featured <span>Collection</span></h2> 
     <div class="container-product">

     <?php
                //Getting products from the data base that are active active and featut=ed
                $sql2 ="SELECT * FROM tbl_detail WHERE active='YES' AND featured='YES' LIMIT 8";

                //Executre the query
                $res2 = mysqli_query($conn, $sql2);

                //count rows to check whther the food is available or not
                $count2 = mysqli_num_rows($res2);

                if($count2>0)
                {
                 //food available
                    
                     while($row=mysqli_fetch_assoc($res2))
                     {
                         //Creat all the values from the database
                       $id = $row['id'];
                       $title = $row['title'];
                       $product_code = $row['product_code'];
                       $price = $row['price'];
                       //$description = $row['description'];
                       $image_name1 = $row['image_name1'];
                      
                       ?>
                <!-- card start-->
                        <div class="card">
                           <div class=imgContainer>
                                <?php
                                  //Check whther the iameg is available or not
                                  if($image_name1=="")
                                  {
                                      //Display message
                                      echo "<div class='error'>Image not available</div>";
                                  }
                                  else
                                  {
                                      //Image available
                                      ?>
                                      <img src="<?php echo SITEURL; ?>images/products/<?php echo $image_name1; ?>" alt="<?php $image_name1; ?>">
                                      <?php
                                  }
                              
                                ?>
        
                            </div>
                            <div class="infoBox">
                              <div class="title">
                               <?php echo $title; ?>  
                              </div>
                              <div class="price-code">
                               <p class="price">Rs<?php echo $price; ?></P>
                               <p class="code"><span>Code:</span><?php echo $product_code; ?></P>
                              </div>

                              <div class="buttonGroup">
                                <a href="<?php echo SITEURL; ?>order.php?product_id=<?php echo $id; ?>"><button class="buy">Buy Now</button></a>
                                <a href="<?php echo SITEURL; ?>product-detail.php?product_id=<?php echo $id; ?>"><button class="seeDetails">See Details</button></a>
                              </div>
                           </div>
                        </div>
                        
                         <?php    
                      }
                }
                else
                {
                    //Foodnot available
                    echo "<div class='error'>Products not added.</div>";
                }

            ?>

      <!-- card ends-->
    </div>
     <div class="see-more-btn text-center">
          <a href="<?php echo SITEURL; ?>product-collection.php" class="product-link">View More Products <i class="fas fa-angle-double-right"></i></a>
     </div>
 </div>       

<!-- product menu ends from here-->

<!-- Owner Profile section starts from here-->
 <section class="owner-profile">
     <h1>Owner Profile</h1>
     <div class="profle-container">
         
        <div class="profile-box">
           <div class="user-icon">
               <img src="images/avatar.png" alt="profile photo">
           </div>
           <div class="user-name">Mr. Robin Ran</div>
           <div class="designation">(Business Owner)</div>

           <div class="user-info">
              <div class="phone">
                <a href="tel:+918485832175"><i class="fa fa-phone"></i> +91-9898986775</a>
              </div>
              <div class="whatsapp">
                <a href="https://wa.me/918485832175" target="_blank"> <i class="fab fa-whatsapp"></i> +91-9898986775</a>
              </div>
              <div class="email">
                <a href="mailto:clothishopgmailcom"> <i class="fa fa-envelope"></i> robinran@gmail.com</a>
              </div>
           </div>    
        </div>

        <div class="profile-box">
           <div class="user-icon">
               <img src="images/avatar.png" alt="profile photo">
           </div>
           <div class="user-name">Mr. Robert John</div>
           <div class="designation">(Manager)</div>

           <div class="user-info">
              <div class="phone">
                <a href="tel:+918485832175"><i class="fa fa-phone"></i> +91-908986775</a>
              </div>
              <div class="whatsapp">
                <a href="https://wa.me/918485832175" target="_blank"> <i class="fab fa-whatsapp"></i> +91-908986775</a>
              </div>
              <div class="email">
                <a href="mailto:clothishopgmailcom"> <i class="fa fa-envelope"></i> robertjohn@gmail.com</a>
              </div>
           </div>    
        </div>
        <!-- box-->
     </div>
 </section>

 <!-- map marking-->
 <section class="contact-us-section">
  <div class="map-marking">
   <div class="map">
    <h3>Map Marking</h3>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3752.0276746789505!2d75.32628636483494!3d19.881053286631168!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bdb986d68e003f9%3A0xd57983f4018f565!2sPaithan%20Gate%2C%20Aurangabad%2C%20Maharashtra%20431001!5e0!3m2!1sen!2sin!4v1652986979966!5m2!1sen!2sin" width="800" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
   </div>
  </div>
 </section>
<!-- Map marking ends-->

 <!--Whatsapp chat option-->
 <div class="shortcut-btns">
    <div class="whatsapp-chat-btn"> 
    <a href="https://wa.me/918485832175" target="_blank"><img src="images/whatsappicon.png" alt="whatsapp icon"></a>
    </div> 
    <div class="calling-btn"> 
    <a href="tel:+988998678" target="_blank"><img src="images/calling1.png" alt="calling icon"></a>
    </div>
 </div>

<script src="script.js"></script>
<?php include('part-front/footer.php'); ?>