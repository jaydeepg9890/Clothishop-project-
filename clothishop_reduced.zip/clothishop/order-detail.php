<?php include('config/constants.php'); ?>
<html>
    <head>
        <title>Order Details - ClothiShop</title>
        <meta name="viewport" content="width=device-width, initial-scale=0.7">
        <link rel="stylesheet" href="css/order-detail1.css"> 
    </head>

<body>
<?php 
         if(isset($_SESSION['order']))
         {
             echo $_SESSION['order'];
             unset($_SESSION['order']);
         }  
            
             $id = $_SESSION['id'];
             //Get the datails of selected product 
             $sql = "SELECT * FROM  tbl_buy WHERE id=$id";
     
             //Execute teh query 
             $res = mysqli_query($conn, $sql);
             //Count the rows
             $count = mysqli_num_rows($res);
              
             if($count==1)
             {
               //we have details
              //GET the value from datbase 
              $row = mysqli_fetch_assoc($res);
              $product = $row['product'];
              $product_code = $row['product_code'];
              $price = $row['price'];
              $delivery = $row['delivery'];
              $total = $price+$delivery;
              $color = $row['color'];
              $size = $row['size'];
              $customer_name = $row['customer_name'];
              $customer_contact = $row['customer_contact'];
              $email = $row['customer_email'];
              $state = $row['state'];
              $pincode = $row['pincode'];
              $country = $row['country'];
              $city = $row['city'];
              $area = $row['area'];
              $landmark = $row['landmark'];
              $house_no = $row['house_no'];
             }
             else
             {
                   //Category not passed 
                 //REdirect to home page 
                 header('location:'.SITEURL);
                 ob_enf_fluch();
             }
            
    
     ?>
   <div class="box">
     <img src="images/clothishop.png" alt="logo" class="logo">
         <h1>Order Details</h1>
     <div class="order-detail">  
       <h3>product Detail:</h3>
       <div class="mineral-detail">  
         <p>product Name:  <span><?php echo $product; ?></span> </p>
         <p>Size: <span><?php echo $size; ?></span> </p>
         <p>Color: <span><?php echo $color; ?></span> </p>
         <p>Total:</P>
         <p><span>$<?php echo $price; ?></span>(Pri.)+<span>$<?php echo $delivery; ?></span>(Del.)=<span><strong>$<?php echo $total; ?></strong></span></p>
       </div>
       <h3>Shipping Detail:</h3>
       <div class="customer-detail">   
         <p>Full Name:<span> <?php echo $customer_name; ?></span></P>
         <p>Phone Number:<span> <?php echo $customer_contact; ?></span></P>
         <p>Email:<span><?php echo $email; ?></span></P>
         <p>Shipping Address:<span> <?php echo $house_no; ?>,<?php echo $landmark; ?>,<?php echo $area; ?>,<?php echo $city; ?>,<?php echo $state; ?>, <?php echo $country; ?>, <?php echo $pincode; ?> </span></P>
       </div>  
            
       <div class="buttongroup">
          <a href="<?php echo SITEURL;?>"><button class="btn-primary">Cancel Order</button></a>

          <a href="<?php echo SITEURL; ?>order-done.php"><button class="btn-secondary">Confirm Order</button></a>
       </div>
    </div>
     <!-- <strong><p class="text-center">Designed and Developed by -<a href="#">Mohammad Azhar</a></p></strong> -->
    </div>

    </body>
</html>    