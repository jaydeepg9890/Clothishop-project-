<?php include('part-front/menu.php'); ?>
     <div class="done">
       <div class="gif-img">
         <img src="images/order tick gif.gif">
       </div>
       <div class="order-done">
         <h2>Your order is successfully done.</h2>
       </div> 
       <div class="btn"> 
         <a href=<?php echo SITEURL; ?>><button type="button" class="btn-secondary"><i class="fas fa-home"> Home</i></button></a>
       </div> 
       <div class="message-box">
          <p>Your Order is successfully done.With in an hour,we will send an e-mail for payment method and details of your order."Thank you for Dealing with us".</P>      
       </div>
     </div> 
<?php include('part-front/footer.php'); ?>