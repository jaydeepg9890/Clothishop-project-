<?php include('part-front/menu.php'); ?>
<?php include('part-front/user-login-check.php'); ?>
<!-- order section starts from Here -->
         <?php 
         //Check whether food id is set or not
         if(isset($_GET['product_id']))
         {
             //food id is passed out
             $product_id = $_GET['product_id'];
     
             //Get the datails of selected food 
             $sql = "SELECT * FROM tbl_detail WHERE id=$product_id";
     
             //Execute teh query 
             $res = mysqli_query($conn, $sql);
             //Count the rows
             $count = mysqli_num_rows($res);
              
             if($count==1) 
             {
               //we have details
              //GET the value from datbase 
              $row = mysqli_fetch_assoc($res);
              $id = $row['id'];
              $title = $row['title'];
              $price = $row['price'];
              $delivery = $row['delivery'];
              $total = $price + $delivery;
              $product_code = $row['product_code'];
              $image_name1 = $row['image_name1'];
              $color = $row['color'];
              $size = $row['size'];
             }
             else
             {
                 //Category not passed 
                 //REdirect to home page 
                 header('location:'.SITEURL);
                 ob_enf_fluch();
             }
            
         }
          else
         {
             //Category not passed 
             //REdirect to home page 
             header('location:'.SITEURL);
             ob_enf_fluch();
         }
        
    
        ?>

    <section class="food-search">
        <div class="container">
            
            <h2 class="text-center text-white">Fill this form to confirm your order.</h2>

            <form action="" method="POST" class="order">
                <fieldset>
                    <legend>Selected Product</legend>
    
                    <div class="food-menu-desc">
                    
                        <h3><?php echo $title; ?></h3>
                        <input type="hidden" name="product" value="<?php echo $title; ?>">
                        
                        <div class="product-code">
                          <p>Product Code:<span> <?php echo $product_code; ?></span></p>
                          <input type="hidden" name="code" value="<?php echo $product_code; ?>">
                        </div>
                        
                        <div class="product-detail">
                          <p>Color:<span> <?php echo $color; ?></span></p>
                          <input type="hidden" name="color" value="<?php echo $color; ?>">

                          <p>Size:<span><?php echo $size; ?></span></P>
                          <input type="hidden" name="size" value="<?php echo $size; ?>">

                          <p>Price:<span> Rs<?php echo $price; ?></span></p>
                          <input type="hidden" name="price" value="<?php echo $price; ?>">

                          <p>Delivery Charges:<span> Rs<?php echo $delivery; ?></span></p>
                          <input type="hidden" name="delivery_charges" value="<?php echo $delivery; ?>">
                          
                          <p>Total:<span> Rs<?php echo $price; ?></span>(Pri.)+<span>Rs<?php echo $delivery; ?></span>(Del.)=<span><strong>Rs<?php echo $total; ?></strong></span></p>
                          <input type="hidden" name="total" value="<?php echo $total; ?>">
                        </div>
                    </div>
                    
                    <div class="mineral-img">
                        <!--<img src="images/stones/stone5.jpg" alt="image 1" class="img-responsive img-curve"> -->
                        <?php
                                  //Check whther the iameg is available or not
                                  if($image_name1=="")
                                  {
                                      //Display message
                                      echo "<div class='error'>Image not available</div>";
                                  }
                                  else
                                  {
                                      //Image available
                                      ?>
                                      <img src="<?php echo SITEURL; ?>images/products/<?php echo $image_name1; ?>" alt="<?php $image_name1; ?>" class="img-responsive img-curve">
                                      <?php
                                  }
                              
                       ?>
                    </div>

                </fieldset>
                
                <fieldset>
                    <legend>Delivery Details</legend>

                    <div class="order-label">Full Name</div>
                    <input type="text" name="full-name" placeholder="Enter your Full name" class="input-responsive" required>

                    <div class="order-label">Phone Number</div>
                      <select name="a_code">
                        <option value="+91">+91</option>
                        <option value="+43">+43</option>
                        <option value="+973">+973</option>
                        <option value="+880">+880</option>
                        <option value="+32">+32</option>
                        <option value="+975">+975</option>
                        <option value="+55">+55</option>
                        <option value="+1">+1</option>
                        <option value="+86">+86</option>
                        <option value="+20">+20</option>
                        <option value="+358">+358</option>
                        <option value="+33">+33</option>
                        <option value="+49">+49</option>
                        <option value="+852">+852</option>
                        <option value="+61">+61</option>
                        <option value="+98">+98</option>
                        <option value="+964">+964</option>
                        <option value="+39">+39</option>
                        <option value="+81">+81</option>
                        <option value="+850">+850</option>
                        <option value="+82">+82</option>
                        <option value="+961">+961</option>
                        <option value="+60">+60</option>
                        <option value="+95">+95</option>
                        <option value="+977">+977</option>
                        <option value="+31">+31</option>
                        <option value="+64">+64</option>
                        <option value="+968">+968</option>
                        <option value="+92">+92</option>
                        <option value="+966">+966</option>
                        <option value="+65">+65</option>
                        <option value="+27">+27</option>
                        <option value="+34">+34</option>
                        <option value="+94">+94</option>
                        <option value="+268">+268</option>
                        <option value="+41">+41</option>
                        <option value="+90">+90</option>
                        <option value="+44">+44</option>
                        <option value="+967">+967</option>
                        <option value="+263">+263</option>
                       <input type="tel" name="contact" placeholder="Enter phone number" class="input-responsive" required>
                      </select>

                    <div class="order-label">E-mail</div>
                    <input type="email" name="email" placeholder="Enter your e-mail" class="input-responsive" required>
                    
                     <div class="order-label">Country</div>
                    <select name="country" class="input-responsive" required>

                       <option value="1" class="options">Select Country</option>
                       <option value="Afghanistan">Afghanistan</option>
                       <option value="Australia">Australia</option>
                       <option value="Austria">Austria</option>
                       <option value="Bahrain">Bahrain</option>
                       <option value="Bangladesh">Bangladesh</option>
                       <option value="Belgium">Belgium</option>
                       <option value="Bhutan">Bhutan</option>
                       <option value="Brazil">Brazil</option>
                       <option value="Canada">Canada</option>
                       <option value="China">China</option>
                       <option value="Egypt">Egypt</option>
                       <option value="Finland">Finland</option>
                       <option value="France">France</option>
                       <option value="Germany">Germany</option>
                       <option value="Hong Kong">Hong Kong</option>
                       <option value="India">India</option>
                       <option value="Iran">Iran</option>
                       <option value="Iraq">Iraq</option>
                       <option value="Italy">Italy</option>
                       <option value="Japan">Japan</option>
                       <option value="Korea (south)">Korea (south)</option>
                       <option value="Korea (north)">Korea (north)</option>
                       <option value="Lebanon">Lebanon</option>
                       <option value="Malaysia">Malaysia</option>
                       <option value="Myanmar">Myanmar</option>
                       <option value="Nepal">Nepal</option>
                       <option value="Netherlands">Netherlands</option>
                       <option value="New Zealand">New Zealand</option>
                       <option value="Oman">Oman</option>
                       <option value="Pakistan">Pakistan</option>
                       <option value="Saudi Arabia">Saudi Arabia</option>
                       <option value="Singapore">Singapore</option>
                       <option value="South Africa">South Africa</option>
                       <option value="Spain">Spain</option>
                       <option value="Sri Lanka">Sri Lanka</option>
                       <option value="Swaziland">Swaziland</option>
                       <option value="Sweden">Sweden</option>
                       <option value="Switzerland">Switzerland</option>
                       <option value="Turkey">Turkey</option>
                       <option value="United Kingdom">United Kingdom</option>
                       <option value="United States">United States</option>
                       <option value="Yemen">Yemen</option>
                       <option value="Zimbabwe">Zimbabwe</option>
                    </select><br><br> 

                    <div class="order-label">State</div>
                      <input type="text" name="state" placeholder="State" class="input-responsive" required>

                    <div class="order-label">City</div>
                      <input type="text" name="city" placeholder="City" class="input-responsive" required>

                    <div class="order-label">Pincode</div>
                      <input type="text" name="pincode" placeholder="Pincode" class="input-responsive" required>

                    <div class="order-label">Landmark</div>
                      <input type="text" name="landmark" placeholder="Landmark" class="input-responsive" required>

                    <div class="order-label">Street/Area</div>
                      <input type="text" name="area" placeholder="Street/area" class="input-responsive" required>

                    <div class="order-label">House no.</div>
                      <input type="text" name="house_no" placeholder="House no. (Optional)" class="input-responsive">                    

                      <input type="submit" name="submit" value="Order" class="btn btn-confirm-order">
                </fieldset>

            </form>
                
            <?php
                date_default_timezone_set('Asia/Kolkata');
                
                //Check whether submit or not
                if(isset($_POST['submit']))
                {
                  //GEt all the details from the data base
                  $product = $_POST['product'];
                  $price = $_POST['price'];
                  $color = $_POST['color'];
                  $size = $_POST['size'];
                  $delivery = $_POST['delivery_charges'];
                  $total = $price + $delivery;
                  $product_code = $_POST['code'];
                  $order_date = date("Y-m-d h:i:sA"); //oder date and time
                  $status = "Ordered"; //oredered, on delivery, delivered,cancelled
                  $customer_name = $_POST['full-name'];
                  $a_code = $_POST['a_code'];
                  $customer_contact = $_POST['contact'];
                  $customer_email = $_POST['email'];
                  $state = $_POST['state'];
                  $pincode = $_POST['pincode'];
                  $country = $_POST['country'];
                  $city = $_POST['city'];
                  $area = $_POST['area'];
                  $landmark = $_POST['landmark'];
                  $house_no = $_POST['house_no'];
    
                   //Seve the order in databse

                   $sql2 = "INSERT INTO tbl_buy SET
                        product = '$product',
                        price = $price,
                        total = $total,
                        color = '$color',
                        size = '$size',
                        delivery = $delivery,
                        product_code = '$product_code',
                        order_date = '$order_date',
                        status = '$status',
                        customer_name = '$customer_name',
                        a_code = $a_code,
                        customer_contact = '$customer_contact',
                        customer_email = '$customer_email',
                        country = '$country',
                        state = '$state',
                        pincode = $pincode,
                        city = '$city',
                        landmark = '$landmark',
                        area = '$area',
                        house_no = '$house_no'        
                        ";
                          
                       //Execute the query
                       $res2 = mysqli_query($conn, $sql2);

                         //Check whther the query is executed or not
                         if($res2==true)
                         {
                         
                          $sql3 = "SELECT * FROM tbl_buy WHERE customer_name='$customer_name'";
      
                          $res3 = mysqli_query($conn, $sql3);
                    
                            while($row=mysqli_fetch_assoc($res3))
                            {
                              $id = $row['id'];
                            }
                          $_SESSION['id'] = "$id";
                          header('location:'.SITEURL.'order-detail.php');
                          ob_enf_fluch();
                         }
                         else
                         {
                         $_SESSION['order'] = "<div class='error text-center'>1 Failed to order the Product.</div>";
                         header('location:'.SITEURL);
                         ob_enf_fluch();
                         }
                       
                }
            ?>


        </div>
    </section>
    <!-- Order sction ends here -->

<?php include('part-front/footer.php'); ?>