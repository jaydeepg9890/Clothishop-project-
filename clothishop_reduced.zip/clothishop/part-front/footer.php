<!-- Footer section starts from here-->
<footer>
       <div class=shout-out>
          <p>Designed & Developed by <span></span>.</p> <p>Click to Contact:<a href="https://instagram.com/mohd_azr_pvt01/"><i class="fab fa-instagram"></i></a> &nbsp;<a href="tel:8793525843"><i class="fas fa-phone"></i></a>&nbsp; <a href="mailto:example@gmailcom"><i class="far fa-envelope"></i></a></p>
        </div>
        <div class="container1">
            <div class="box">
                <h3>About US</h3>
                <P>We have many Varieties of cloths.We sell cloths at decent price and wholesale price.We have all types of cotton garments.We accept gpay,phonepay payments too.Contact us to know more about our minerals and services.</p>
                <h4>Follow Us on:</h4>
                <div class="social">
                    <a href="#">
                        <i class="fab fa-facebook"></i>
                    </a>
                    <a href="#">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="#">
                        <i class="fab fa-instagram"></i>
                    </a>    
                </div>
            </div>
            <div class="box">
                <h3>Address</h3>
                <div class="address">
                    <a>
                       <i class="fas fa-map-marker-alt"></i>
                       Aurangabad 431001,Maharashtra,India
                    </a>
                    
                    <a href="tel:09876543">
                        <i class="fas fa-phone-square-alt"></i>
                        +91-9879747875
                    </a>    

                    <a href="mailto:clothishop@gmail.com">
                        <i class="fas fa-envelope"></i>
                        clothishop@gmail.com
                    </a>    
                </div>
            </div>
            <div class="box">
                <h3>Contact Us</h3>

                <form action="" method="POST">
                    <label for="name">Full name<span>*</span></label>
                    <input type="text" name="full_name" required>

                    <label for="mail">Email<span>*</span></label>
                    <input type="email" name="email" required>

                    <label for="mess">Message <span>*</span></label>
                    <textarea name="message" rows="3" required></textarea>
                    <input type="submit" name="submit" value="Send" class="btn btn-confirm-order">
                </form>
            </div>
        </div>

        <div class="author">
            
            <p>©All rights 2025 reserved by <span>Clothishop</span></p>
        </div>
    </footer>
    <!--Footer Sections  ends-->

    </body>
</html>
<?php
     //process the value from form and save it in database.

     //check wether the submit button is clicked or not.

     if(isset($_POST['submit']))
     {
         // button clicked.
         //echo "button clicked";
     
         //1.Get the data from form
         $full_name = $_POST['full_name'];
         $email = $_POST['email'];
         $message = $_POST['message']; 

         //2.sql query to save the sata into database.
         $sql = "INSERT INTO tbl_contact_us SET
           full_name='$full_name',
           email='$email',
           message='$message'
         ";

        //3.Executing the query and saving data into database 
        $res = mysqli_query($conn, $sql) or die(mysql_error());
  
        //4.check wether the query is executed data is inserted or not and display appropriate message.
        if($res==TRUE)
        {
           //data inserted
           //create a session variable to display the message
           $_SESSION['msg-sent'] = "<div class='success text-center'>Message sent.We will response you as soon as possible.</div>";
           //redirect to homepage
           header("location:".SITEURL);
           ob_enf_fluch();
        } 
        else
        {
           //Data is not inserted
           //create a session variable to display the message
           $_SESSION['mesg-not-sent'] = "<div class='error text-center'>Message failed to send.</div>";
           //redirect to homepage
           header("location:".SITEURL);
           ob_enf_fluch();
        } 
  
     }     
         
 ?>