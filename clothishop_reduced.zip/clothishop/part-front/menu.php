<?php ob_start(); ?>
<?php include('config/constants.php'); ?>



<!DOCTYPE html>
<html lang="en">
<head>
    <title>Clothishop - Online Cloth Store</title>
    <meta charset="UTF-8">
    <meta name="description" content="We have all varieties of cloths.Beautiful and attractive cloths at cheap prices.All over India delivery services.">
    <meta name="keyword" content="Cloths,Beautiful shirts,Skirt">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    
    <!-- Favicon icons-->
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
    <link rel="manifest" href="site.webmanifest">

    <!-- Link our CSS file -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" type="css/text" href="css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide|Sofia|Trirong">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
</head>

<body>

     <!-- contact and search-->
     <div class="upper-bar">
        <div class="contact">  
           <p> <i class="fas fa-phone"> </i> <a href="tel:+91-8485832175" class="text-black">+91-8485895556</a>&nbsp;&nbsp;&nbsp; <i class="far fa-envelope"></i> <a href="mailto:clothishop@gmailcom" class="text-black">clothishop@gmail.com</a></p>
        </div>  
        <div class="search-box">
          <form action="<?php echo SITEURL; ?>product-search.php" method="POST">
                <input type="search" name="search" placeholder="Search...." required>
                <button type="submit" name="submit"><i class ="fa fa-search"></i></button>
          </form>
        </div>  
     </div>
  
    <section class="nav">   
        <nav> 
           <input type="checkbox" id="check">
            <label for="check" class="checkbtn">
               <i class="fas fa-bars"></i>
            </label>    
            
            <label class="logo">
              <a href="index.php"><i class='bx bxs-t-shirt'></i>ClothiShop</a>
            </label>
                <ul>
                    <li>
                        <a class="active" href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="product-collection.php"> All    Collection </a>
                    </li>
                    <li>
                        <a href="gallery.php">Gellery </a>
                    </li>
                    <li> 
                        <a href="contact-us.php">Contact Us </a>
                    </li>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <!-- Displaying the login and logout option on navigation bar-->
                    <?php
   
                     //Authorization : access control to homepage
                     //Check Wether the user is logged in or not
                     if(!isset($_SESSION['user-login']))    //if user session is set
                     {
                        //User is not loged in
                        ?>
                         <li>
                         <a href="user-login.php"><i class="fas fa-user"></i>&nbsp;Login</a>
                         </li>
                         <li>
                         <a href="user-signup.php"><i class="fas fa-user-plus"></i>&nbsp;Sign up</a>
                         </li>
                        <?php 
                     }
                     else
                     {
                        ?>
                        <li>
                        <a href="<?php echo SITEURL; ?>user-logout.php"><i class="fas fa-sign-out-alt"></i>&nbsp;Logout</a>
                        </li>
                       <?php 
                     }

                    ?> 
               </ul>
          </nav>
</section>

    <!-- Navbar Section Ends Here -->

