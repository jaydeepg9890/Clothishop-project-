<?php ob_start(); ?>
<?php
   
   //Authorization : access control
   //Check Wether the user is logged in or not
   if(!isset($_SESSION['user-login']))    //if user session is set
   {
       //User is not loged in
       //Redirect to log in page with message 
       
       $_SESSION['no-login-message'] = "<div class='error text-center'>Please first Login to order the Minerals.</div>";
       //redirect to home page dashboard
       header('location:'.SITEURL.'user-login.php');
       ob_enf_fluch();
   }

?>