<?php include('part-front/menu.php'); ?>
  
        <!--meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">-->
        <title>Product Detail</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/product-detail1.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous"/>
    </head>
    <body>
  
    <?php 
         //Check whether product id is set or not
         if(isset($_GET['product_id']))
         {
             //product id is passed out
             $product_id = $_GET['product_id'];
     
             //Get the datails of selected product
             $sql = "SELECT * FROM  tbl_detail WHERE id=$product_id";
     
             //Execute teh query 
             $res = mysqli_query($conn, $sql);
             //Count the rows
             $count = mysqli_num_rows($res);
              
             if($count==1)
             {
               //we have details
              //GET the value from datbase 
              $row = mysqli_fetch_assoc($res);
              $id = $row['id'];
              $title = $row['title'];
              $product_code = $row['product_code'];
              $price = $row['price'];
              $delivery = $row['delivery'];
              $total = $price + $delivery;
              $color = $row['color'];
              $size = $row['size'];
              $type = $row['ftype'];
              $category_name = $row['category_name'];
              $shiping = $row['shipping_area'];
              $image_name1 = $row['image_name1'];
              $image_name2 = $row['image_name2'];
              $image_name3 = $row['image_name3'];
              $image_name4 = $row['image_name4'];
              $description = $row['description'];
              $active = $row['active'];
              $featured = $row['featured'];
             }
             else
             {
                   //Category not passed 
                 //REdirect to home page 
                 header('location:'.SITEURL);
                 ob_enf_fluch();
             }
            
         }
          else
         {
             //Category not passed 
             //REdirect to home page 
             header('location:'.SITEURL);
             ob_enf_fluch();
         }
        
    
     ?>


      <div class="card-wrapper">
        <div class="detail-card">
            <!-- left card-->
            <div class="product-imgs">
              <div class="img-display">
                 <div class="img-showcase">
                    
         <?php 
        //Check whther the image is available or not
         if($image_name1=="")
         {  
           //Display message
           echo "<div class='error'>Image not available</div>";
         }
         else
         {
          //Image available
          ?>
           <img src="<?php echo SITEURL; ?>images/products/<?php echo $image_name1; ?>" alt="<?php $image_name1; ?>">
          <?php
         } 
          ?>

        <?php 
        //Check whther the image is available or not
         if($image_name2=="")
         {  
           //Display message
           echo "<div class='error'>Image not available</div>";
         }
         else
         {
          //Image available
          ?>
           <img src="<?php echo SITEURL; ?>images/products/<?php echo $image_name2; ?>" alt="<?php $image_name2; ?>">
          <?php
         } 
          ?>

        <?php  
        //Check whther the image is available or not
         if($image_name3=="")
         {  
           //Display message
           echo "<div class='error'>Image not available</div>";
         }
         else
         {
          //Image available
          ?>
           <img src="<?php echo SITEURL; ?>images/products/<?php echo $image_name3; ?>" alt="<?php $image_name3; ?>">
          <?php
         } 
          ?>

        <?php 
        //Check whther the image is available or not
         if($image_name4=="")
         {  
           //Display message
           echo "<div class='error'>Image not available</div>";
         }
         else
         {
          //Image available
          ?>
           <img src="<?php echo SITEURL; ?>images/products/<?php echo $image_name4; ?>" alt="<?php $image_name4; ?>">
          <?php
         } 
          ?>


                </div>
              </div>
              <div class="img-select">
                <div class="img-item">
                  <a href="#" data-id="1">
                  
                  <?php 
                   //Check whther the image is available or not
                   if($image_name1=="")
                   {  
                    //Display message
                    echo "<div class='error'>Image not available</div>";
                   }
                   else
                   {
                    //Image available
                  ?>
                    <img src="<?php echo SITEURL; ?>images/products/<?php echo $image_name1; ?>" alt="<?php $image_name1; ?>">
                  <?php
                   } 
                 ?>  
                  </a>  
              </div> 

                <div class="img-item">
                  <a href="#" data-id="2">
                   
                  <?php 
                   //Check whther the image is available or not
                   if($image_name2=="")
                   {  
                    //Display message
                    echo "<div class='error'>Image not available</div>";
                   }
                   else
                   {
                    //Image available
                   ?>
                    <img src="<?php echo SITEURL; ?>images/products/<?php echo $image_name2; ?>" alt="<?php $image_name2; ?>">
                   <?php
                   } 
                   ?>  
                  </a>  
                </div>

                <div class="img-item">
                  <a href="#" data-id="3">
                    <?php 
                   //Check whther the image is available or not
                   if($image_name3=="")
                   {  
                    //Display message
                    echo "<div class='error'>Image not available</div>";
                   }
                   else
                   {
                    //Image available
                   ?>
                    <img src="<?php echo SITEURL; ?>images/products/<?php echo $image_name3; ?>" alt="<?php $image_name3; ?>">
                   <?php
                   } 
                   ?>  
                  </a>  
                </div>

                <div class="img-item">
                  <a href="#" data-id="4">
                    
                    <?php 
                   //Check whther the image is available or not
                   if($image_name4=="")
                   {  
                    //Display message
                    echo "<div class='error'>Image not available</div>";
                   }
                   else
                   {
                    //Image available
                   ?>
                    <img src="<?php echo SITEURL; ?>images/products/<?php echo $image_name4; ?>" alt="<?php $image_name4; ?>">
                   <?php
                   } 
                   ?>  
                </a>
              </div>
              </div>
            </div>
            <!-- Right card-->
            <div class="product-content">
               <h2 class="product-title"> <?php echo $title; ?></h2> 
               
               <div class="mineral-code">
                 <p>Product Code: <span> <?php echo $product_code; ?></span></p>
               </div>
               
               <div class="product-price">
                 <!-- <p class="last-price">Market Price: <span> Rs<?php echo $market_price; ?></span></p> -->

                 <p class="new-price">Price: <span>Rs<?php echo $price; ?></span></p>
               </div>
 
               <div class="delivery-charges">
                 <p class="delivery">Delivery Charges: <span>$<?php echo $delivery; ?></span></p>
               </div>
               
               <div class="product-detail">
                  <ul>
                    <li>Fabric Type: <span><?php echo $type; ?></span></li>
                    <li>Colour: <span><?php echo $color; ?></span></li>
                    <li>Category: <span><?php echo $category_name; ?></span></li>
                    <li>Size:<span><?php echo $size; ?></span></li>
                    <li>Category Name: <span><?php echo $category_name; ?></span></li>
                    <li>Shipping Area: <span><?php echo $shiping; ?></span></li>
                  </ul>
                  
                <h2>Description<h2>
                   <p><?php echo $description; ?></p>  
               </div>
                  
               <div class="purchase">
                 
                 <a href="<?php echo SITEURL; ?>order.php?product_id=<?php echo $id; ?>"><button type="button" class="btn-purchase">Proceed to Buy<i class="fas fa-shopping-bag"></i></button></a>
                 
                 <a href="product-collection.php" class="product-link">View More Products<i class="fas fa-angle-double-right"></i></a>
               </div>
            </div>   
        </div>
     </div>   
     <script src="productscript.js"></script>
<?php include('part-front/footer.php'); ?>
        
