<?php include('part-front/menu.php'); ?>

      <!-- Porduct menu stars from here-->
   
     <?php   
                 //Get the search keyword
                 $search = $_POST['search']; 
         ?>
       <p>Search Result....</p>
       <div class="mineral-collection">
         <h2 class="text-center">Collection Based on <span>"<?php echo $search; ?>"</span> Search</h2> 
       </div>
  <div class="product-menu">
       <div class="container-product">
         <?php
                 //SQL query to to get products based on search keyword
                 $sql = "SELECT * FROM tbl_detail WHERE active='YES' AND title LIKE '%$search%' OR description LIKE '%$search%'";

                //Executre the query
                $res = mysqli_query($conn, $sql);

                //count rows to check whther the food is available or not
                $count = mysqli_num_rows($res);

                if($count>0)
                {
                 //food available
                    
                     while($row=mysqli_fetch_assoc($res))
                     {
                         //Creat all the values from the database
                       $id = $row['id'];
                       $title = $row['title'];
                       $product_code = $row['product_code'];
                       $price = $row['price'];
                       //$description = $row['description'];
                       $image_name1 = $row['image_name1'];
                      
                       ?>
                <!-- card start-->
                        <div class="card">
                           <div class=imgContainer>
                                <?php
                                  //Check whther the iameg is available or not
                                  if($image_name1=="")
                                  {
                                      //Display message
                                      echo "<div class='error'>Image not available</div>";
                                  }
                                  else
                                  {
                                      //Image available
                                      ?>
                                      <img src="<?php echo SITEURL; ?>images/products/<?php echo $image_name1; ?>" alt="<?php $image_name1; ?>">
                                      <?php
                                  }
                              
                                ?>
        
                            </div>
                            <div class="infoBox">
                              <div class="title">
                               <?php echo $title; ?>  
                              </div>
                              <div class="price-code">
                               <p class="price">Rs<?php echo $price; ?></P>
                               <p class="code"><span>Code:</span><?php echo $product_code; ?></P>
                              </div>

                              <div class="buttonGroup">
                                <a href="<?php echo SITEURL; ?>order.php?product_id=<?php echo $id; ?>"><button class="buy">Buy Now</button></a>
                                <a href="<?php echo SITEURL; ?>product-detail.php?product_id=<?php echo $id; ?>"><button class="seeDetails">See Details</button></a>
                                
                              </div>
                           </div>
                        </div>
                        
                         <?php    
                      }
                }
                else
                {
                    //Foodnot available
                    echo "<div class='error'>products not added.</div>";
                }

            ?>

      <!-- card ends-->
    </div>
 </div>       

<!-- product menu ends from here-->

<?php include('part-front/footer.php'); ?>