<?php ob_start(); ?>
<?php include('config/constants.php'); ?>

<html>
    
    <head>
        <title>User Login | Clothishop</title>
        <meta name="viewport" content="width=device-width, initial-scale=0.7">
        <link rel="stylesheet" href="css/user-login3.css"> 
        <link rel="stylesheet" type="css/text" href="css/all.min.css">
        <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    </head>

    <body>
         <div class="login">
            <img src="images/clothishop.png" alt="logo" class="logo logo-position">
            <h1><i class="fas fa-user"></i>&nbsp;Login</h1>
    
        <?php

                if(isset($_SESSION['sign-up']))
                { 
                echo $_SESSION['sign-up'];
                unset($_SESSION['sign-up']);
                }
                
                if(isset($_SESSION['login']))
                {
                  echo $_SESSION['login']; //Displaying the message
                  unset($_SESSION['login']); //Removing the message
                }

                if(isset($_SESSION['no-login-message']))
                {
                  echo $_SESSION['no-login-message']; //Displaying the message
                  unset($_SESSION['no-login-message']); //Removing the message
                } 
                
        ?><br><br>



            <!--Login form starts fromn here-->
            <form action="" method="POST">
            <p>Username:</p>
            <input type="text" name="username" placeholder="Enter Username" required><br><br>

            <p>Password:</p>
            <input type="password" name="password" placeholder="Enter Password"> <br><br>

            <input type="submit" name="submit" value="Login" class="btn-secondary"><br> <br>
             <p class="text-center">If you don't have account then  <a href="user-signup.php" class="btn-primary">Sign up</a></p>
             <br>
             </br>
            </form>
            <!--Login form ends-->
             <p class="text-center">Designed and Developed by -<a href="#" class="text-color">Mohammad Azhar</a></p>
        </div>

    </body>
</html>

<?php
     //Check whther the submit is clicked or not
     if(isset($_POST['submit']))
     {
         //process for login
         //1.Get the data from logni from
        $username = $_POST['username'];
        $password = md5($_POST['password']);

        //2.SQL to check whther the user with username and password exists
        $sql = "SELECT * FROM tbl_user WHERE username='$username' AND password='$password'";

        //xecutee the query
        $res = mysqli_query($conn , $sql);

        //4Count the rows to check whther the user exists or not
        $count = mysqli_num_rows($res);

        if($count==1)
        {
         //User is vaialable and login success
         $_SESSION['login'] = "<div class='success text-center'>Login successful.</div>";
          
         $_SESSION['user-login'] = $username; //to check whther the user is loged in or not and logout will unset it

         //redirect to home page 
         header('location:'.SITEURL);
         ob_enf_fluch();
        }
        else
        {
          //User not available nad login failed
          $_SESSION['login'] = "<div class='error text-center'>Username or Password does not match!</div>";
          //redirect to home page dashboard
          header('location:'.SITEURL.'user-login.php');
          ob_enf_fluch();
        }
    }
?>