<?php 
    //including constants.php for SITEURL 
    include('config/constants.php');
    //1. Destroy the session 
    session_destroy(); //unset the session
   
   
    
    //2.Redirect to login page with message
    
    header('location:'.SITEURL);
?>