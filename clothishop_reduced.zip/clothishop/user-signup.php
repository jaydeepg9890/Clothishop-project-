<?php ob_start(); ?>
<?php include('config/constants.php'); ?>
<html>
    
    <head>
        <title>Sign-up - Clothishop</title>
        <meta name="viewport" content="width=device-width, initial-scale=0.7">
        <link rel="stylesheet" href="css/user-login3.css">
        <link rel="stylesheet" type="css/text" href="css/all.min.css">
        <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    </head>

    <body>
    <div class="login">
        <img src="images/clothishop.png" alt="logo" class="logo">
        <h1><i class="fas fa-user-plus"></i>&nbsp;Sign-up</h1>
      
         <?php
            if(isset($_SESSION['sign-up-error']))
                {
                  echo $_SESSION['sign-up-error']; //Displaying the message
                  unset($_SESSION['sign-up-error']); //Removing the message
                }

            if(isset($_SESSION['user-exist']))
                {
                  echo $_SESSION['user-exist']; //Displaying the message
                  unset($_SESSION['user-exist']); //Removing the message
                }
         ?>
          

          <!--Login form starts fromn here-->
           <form action="" method="POST">
             <p> First Name:</P>
                <input type="text" name="first_name" placeholder="Enter your First Name" required><br>

              <p> Last Name:</P>
                <input type="text" name="last_name" placeholder="Enter your Last Name" required><br>

              <p> Phone Number:</P>
               <input type="tel" name="contact" placeholder="Enter your Phone Number" required><br>

              <p> E-mail:</P> 
                <input type="email" name="email" placeholder="Enter your E-mail" required><br> 

              <p>Username:</P>
                <input type="text" name="username" placeholder="Enter Username" required><br>
  
              <p>Password:</p>
                <input type="password" name="password" placeholder="Enter Password" required> <br>

                <input type="submit" name="submit" value="Sign-up" class="btn-primary ">
            
           </form>
          <!--Login form ends-->
             <p class="text-center">Designed and Developed by -<a href="#" class="text-color">Mohammad Azhar</a></p>
    </div>

    </body>
</html>    


<?php
     //process the value from form and save it in database.

     //check wether the submit button is clicked or not.

     if(isset($_POST['submit']))
     {
         // button clicked.
         //echo "button clicked";
     
         //1.Get the data from form
         $first_name = $_POST['first_name'];
         $last_name = $_POST['last_name'];
         $contact = $_POST['contact'];
         $email = $_POST['email'];
         $username = $_POST['username'];
         $password = md5($_POST['password']); //password encryption with md5   
        
         //check Whether th eusername is available is not
         //2.Create SQL query to check username available or not
         $sql = "SELECT * FROM tbl_user WHERE username='$username'";

         //xecutee the query
         $res = mysqli_query($conn , $sql);

         //3.Count the rows to check whther the user exists or not
         $count = mysqli_num_rows($res);
    
         if($count>0)
         {
           //Username already Exist
           //Display Message
           $_SESSION['user-exist'] = "<div class='error text-center'>Username already exist.</div>";
           //redirect page to add home page
            header('location:'.SITEURL.'user-signup.php'); 
            ob_enf_fluch();
         }
         else
         {
               //4.sql query to save the sata into database.
               $sql1 = "INSERT INTO tbl_user SET
                       first_name='$first_name',
                       last_name='$last_name',
                       contact='$contact',
                       email='$email',
                       username='$username',
                       password='$password'
                       ";
      
               //5.Executing the query and saving data into database 
               $res1 = mysqli_query($conn, $sql1) or die(mysql_error());

               //4.check wether the query is executed data is inserted or not and display appropriate message.
               if($res1==TRUE)
               {
                 //data inserted
                 //echo "Data Inserted";
                 //create a session variable to display the message

                 $_SESSION['email'] = "$email";
                 //redirect on page to shoot otp
                 header('location:'.SITEURL.'user-login.php');
                 $_SESSION['sign-up'] = "<div class='success text-center'>Sign-up Successfull.</div>";
                 ob_enf_fluch();
               }   
          }
     }
     

 ?>